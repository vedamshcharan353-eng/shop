# 🍽️ Restaurant Sticker Loyalty System

A full-stack digital sticker loyalty card system for restaurants. Customers collect digital stickers by scanning QR codes after each purchase — 7 stickers earns a **FREE food reward**.

---

## 📍 Restaurant Info

- **Address:** 16-127, Station Rd, Gandhi Nagar Colony, Shadnagar, Telangana 509216
- **Phone:** +91 90321 10007
- **Hours:** 12:00 PM – 11:30 PM (daily)

---

## ✨ Features

### Customer Features
- 📱 Signup / Login
- 🎴 Digital sticker card with visual progress
- 📷 QR code scanner via phone camera
- ⭐ Real-time sticker collection
- 🎁 Reward tracking and redemption codes
- 📋 Scan history
- ⏰ Expiry countdown (30 days)

### Admin Features
- 🎛️ Restaurant admin panel
- 📱 QR code generator & downloader
- 👥 Customer management with progress tracking
- 🎁 Reward redemption system (by code)
- 📊 Analytics dashboard with charts
- ⚙️ Restaurant settings management

### System Features
- 🔒 JWT authentication
- 🛡️ Fraud prevention (10-minute scan cooldown)
- ⏰ Cron jobs: card expiration + reminders
- 📧 Email reminder notifications
- 🔔 Web push notifications
- 📐 Mobile-first responsive design

---

## 🏗️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router v6, Tailwind CSS |
| Backend | Node.js, Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT (jsonwebtoken + bcryptjs) |
| QR Codes | `qrcode` (generation) + `html5-qrcode` (scanning) |
| Email | Nodemailer (Gmail SMTP) |
| Push | Web Push (VAPID) |
| Scheduler | node-cron |
| Security | helmet, express-rate-limit |

---

## 📁 Project Structure

```
restaurant-sticker-loyalty/
├── backend/
│   ├── config/
│   │   └── db.js                 # MongoDB connection
│   ├── controllers/
│   │   ├── authController.js     # Auth (register, login)
│   │   ├── stickerController.js  # Scan, stickers, rewards
│   │   └── adminController.js    # Admin panel operations
│   ├── cron/
│   │   └── reminderJob.js        # Expiry + reminder cron jobs
│   ├── middleware/
│   │   └── auth.js               # JWT middleware
│   ├── models/
│   │   ├── User.js
│   │   ├── Restaurant.js
│   │   ├── StickerCard.js
│   │   ├── QRCode.js
│   │   ├── Scan.js
│   │   └── Reward.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── stickers.js
│   │   ├── admin.js
│   │   └── restaurants.js
│   ├── services/
│   │   └── notificationService.js # Email + push notifications
│   ├── .env.example
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── public/
│   │   ├── index.html
│   │   └── manifest.json
│   ├── src/
│   │   ├── components/
│   │   │   ├── LoadingSpinner.js
│   │   │   ├── Navigation.js
│   │   │   └── StickerCard.js
│   │   ├── context/
│   │   │   └── AuthContext.js
│   │   ├── pages/
│   │   │   ├── HomePage.js
│   │   │   ├── LoginPage.js
│   │   │   ├── RegisterPage.js
│   │   │   ├── DashboardPage.js
│   │   │   ├── ScanPage.js
│   │   │   ├── RewardsPage.js
│   │   │   ├── HistoryPage.js
│   │   │   └── admin/
│   │   │       ├── AdminLoginPage.js
│   │   │       ├── AdminDashboardPage.js
│   │   │       ├── QRGeneratorPage.js
│   │   │       ├── CustomersPage.js
│   │   │       ├── AdminRewardsPage.js
│   │   │       └── AnalyticsPage.js
│   │   ├── services/
│   │   │   └── api.js
│   │   ├── App.js
│   │   ├── index.js
│   │   └── index.css
│   └── package.json
├── .gitignore
├── package.json
└── README.md
```

---

## 🚀 Installation & Setup

### Prerequisites
- Node.js v16+
- MongoDB (local or Atlas)
- npm or yarn
- Git

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/restaurant-sticker-loyalty.git
cd restaurant-sticker-loyalty
```

### 2. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/restaurant_loyalty
JWT_SECRET=your_very_secret_key_change_this

# Email (Gmail)
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_google_app_password

# Frontend URL
FRONTEND_URL=http://localhost:3000
```

> **Note:** For Gmail, enable 2FA and create an **App Password** at https://myaccount.google.com/apppasswords

### 3. Frontend Setup

```bash
cd ../frontend
npm install
```

Create `frontend/.env`:
```env
REACT_APP_API_URL=http://localhost:5000/api
```

### 4. Start the Application

**Terminal 1 — Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm start
```

### 5. Seed Admin Account

```bash
curl -X POST http://localhost:5000/api/seed
```

Or open: `http://localhost:5000/api/seed` in browser (POST request)

Default credentials:
- **Admin:** admin@restaurant.com / admin123456

---

## 🌐 Deployment

### Backend (Railway / Render / Heroku)

1. Push code to GitHub
2. Connect repo to Railway/Render
3. Set environment variables
4. Deploy — it runs `node server.js`

### Frontend (Vercel / Netlify)

1. Build: `cd frontend && npm run build`
2. Deploy the `build/` folder
3. Set `REACT_APP_API_URL` to your backend URL

### MongoDB Atlas (Production Database)

1. Create free cluster at https://cloud.mongodb.com
2. Whitelist your server IP
3. Update `MONGODB_URI` in backend `.env`

---

## 🔧 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Customer registration |
| POST | `/api/auth/login` | Customer login |
| POST | `/api/auth/admin/login` | Admin login |
| GET | `/api/auth/me` | Get current user |

### Customer (Requires Auth)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/stickers/scan` | Process QR scan (+1 sticker) |
| GET | `/api/stickers/:restaurantId` | Get active sticker card |
| GET | `/api/stickers/cards` | Get all user's cards |
| GET | `/api/stickers/rewards` | Get user rewards |
| GET | `/api/stickers/history` | Get scan history |

### Admin (Requires Admin Auth)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/analytics` | Dashboard stats |
| POST | `/api/admin/qr/generate` | Generate QR code |
| GET | `/api/admin/qr` | List all QR codes |
| PUT | `/api/admin/qr/:id/toggle` | Enable/disable QR |
| GET | `/api/admin/customers` | List customers |
| GET | `/api/admin/rewards` | List rewards |
| PUT | `/api/admin/rewards/:code/redeem` | Redeem a reward |

---

## ⏰ Reminder Schedule

The system sends notifications at these intervals before card expiry:

| Trigger | Message |
|---------|---------|
| Every 3 days | "X days left before stickers expire" |
| 1 day remaining | "1 day left before stickers expire" |
| 3 hours remaining | "3 hours left before stickers expire" |
| Last 1 hour | "Last 1 hour left before stickers expire" |

Cron jobs run:
- **Expiration check:** Daily at midnight
- **Reminder check:** Every 3 hours

---

## 🛡️ Fraud Prevention

- **10-minute cooldown** between scans from the same user on the same QR
- **Rate limiting:** 100 requests/15 min globally, 5 scan attempts/10 min
- **JWT validation** on all protected routes
- **QR token validation** — tokens must exist and be active
- **Business hours enforcement** — scans blocked outside operating hours

---

## 📱 QR Code Flow

1. Admin generates QR code in admin panel
2. QR encodes URL: `https://yourapp.com/scan/{token}`
3. Customer opens app → Scan page → camera opens
4. Camera reads QR → extracts token → calls `/api/stickers/scan`
5. Backend validates token, checks fraud, adds sticker
6. Customer sees animated sticker card update

---

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

---

## 📄 License

MIT License — free to use and modify.

---

*Built with ❤️ for The Loyalty Kitchen, Shadnagar*
