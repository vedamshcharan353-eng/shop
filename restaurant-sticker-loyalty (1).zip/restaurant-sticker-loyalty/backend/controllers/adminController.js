const QRCodeModel = require('../models/QRCode');
const Restaurant = require('../models/Restaurant');
const User = require('../models/User');
const Scan = require('../models/Scan');
const StickerCard = require('../models/StickerCard');
const Reward = require('../models/Reward');
const qrcode = require('qrcode');

// @desc    Get restaurant analytics
// @route   GET /api/admin/analytics
exports.getAnalytics = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOne({ ownerId: req.user._id });
    if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found.' });

    const [totalCustomers, totalScans, stickersIssued, rewardsRedeemed, pendingRewards,
      recentScans, todayScans] = await Promise.all([
      StickerCard.distinct('userId', { restaurantId: restaurant._id }).then(ids => ids.length),
      Scan.countDocuments({ restaurantId: restaurant._id, status: 'valid' }),
      Scan.countDocuments({ restaurantId: restaurant._id, status: 'valid' }),
      Reward.countDocuments({ restaurantId: restaurant._id, redeemed: true }),
      Reward.countDocuments({ restaurantId: restaurant._id, redeemed: false, isExpired: false }),
      Scan.find({ restaurantId: restaurant._id, status: 'valid' })
        .populate('userId', 'name email')
        .sort({ scanTime: -1 }).limit(10),
      Scan.countDocuments({
        restaurantId: restaurant._id,
        status: 'valid',
        scanTime: { $gte: new Date(new Date().setHours(0, 0, 0, 0)) }
      })
    ]);

    // Weekly scan data for chart
    const weeklyScans = await Scan.aggregate([
      {
        $match: {
          restaurantId: restaurant._id,
          status: 'valid',
          scanTime: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
        }
      },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$scanTime' } },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      success: true,
      analytics: {
        totalCustomers,
        totalScans,
        stickersIssued,
        rewardsRedeemed,
        pendingRewards,
        todayScans,
        weeklyScans,
        recentScans
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Generate QR code
// @route   POST /api/admin/qr/generate
exports.generateQR = async (req, res) => {
  try {
    const { label, tableNumber } = req.body;
    const restaurant = await Restaurant.findOne({ ownerId: req.user._id });
    if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found.' });

    const qrRecord = await QRCodeModel.create({
      restaurantId: restaurant._id,
      label: label || `Table ${tableNumber || 'QR'}`,
      tableNumber
    });

    const scanUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/scan/${qrRecord.token}`;
    const qrImageDataUrl = await qrcode.toDataURL(scanUrl, {
      width: 300,
      margin: 2,
      color: { dark: '#1a1a2e', light: '#ffffff' }
    });

    qrRecord.qrImageUrl = qrImageDataUrl;
    await qrRecord.save();

    res.json({
      success: true,
      message: 'QR code generated!',
      qr: {
        id: qrRecord._id,
        token: qrRecord.token,
        label: qrRecord.label,
        tableNumber: qrRecord.tableNumber,
        scanUrl,
        qrImageDataUrl
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all QR codes for restaurant
// @route   GET /api/admin/qr
exports.getQRCodes = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOne({ ownerId: req.user._id });
    if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found.' });

    const qrCodes = await QRCodeModel.find({ restaurantId: restaurant._id }).sort({ createdAt: -1 });

    const qrsWithUrl = qrCodes.map(qr => ({
      ...qr.toObject(),
      scanUrl: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/scan/${qr.token}`
    }));

    res.json({ success: true, qrCodes: qrsWithUrl });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Toggle QR code active status
// @route   PUT /api/admin/qr/:id/toggle
exports.toggleQR = async (req, res) => {
  try {
    const qr = await QRCodeModel.findById(req.params.id);
    if (!qr) return res.status(404).json({ success: false, message: 'QR code not found.' });

    qr.isActive = !qr.isActive;
    await qr.save();

    res.json({ success: true, message: `QR code ${qr.isActive ? 'activated' : 'deactivated'}.`, qr });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all customers for restaurant
// @route   GET /api/admin/customers
exports.getCustomers = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOne({ ownerId: req.user._id });
    if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found.' });

    const cards = await StickerCard.find({ restaurantId: restaurant._id })
      .populate('userId', 'name email phone createdAt')
      .sort({ updatedAt: -1 });

    const customerMap = {};
    for (const card of cards) {
      if (!card.userId) continue;
      const uid = card.userId._id.toString();
      if (!customerMap[uid]) {
        customerMap[uid] = {
          user: card.userId,
          totalStickers: 0,
          activeCard: null,
          totalCards: 0
        };
      }
      customerMap[uid].totalCards++;
      if (!card.isExpired && !card.isCompleted) {
        customerMap[uid].activeCard = card;
      }
      customerMap[uid].totalStickers += card.stickersCollected;
    }

    res.json({ success: true, customers: Object.values(customerMap) });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Redeem reward
// @route   PUT /api/admin/rewards/:code/redeem
exports.redeemReward = async (req, res) => {
  try {
    const reward = await Reward.findOne({ rewardCode: req.params.code })
      .populate('userId', 'name email');

    if (!reward) return res.status(404).json({ success: false, message: 'Reward not found.' });
    if (reward.redeemed) return res.status(400).json({ success: false, message: 'Reward already redeemed.' });
    if (reward.isExpired) return res.status(400).json({ success: false, message: 'Reward has expired.' });

    reward.redeemed = true;
    reward.redeemedAt = new Date();
    reward.redeemedBy = req.user._id;
    await reward.save();

    res.json({
      success: true,
      message: 'Reward redeemed successfully!',
      reward: {
        code: reward.rewardCode,
        customerName: reward.userId?.name,
        customerEmail: reward.userId?.email,
        description: reward.rewardDescription,
        redeemedAt: reward.redeemedAt
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get pending rewards
// @route   GET /api/admin/rewards
exports.getRewards = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOne({ ownerId: req.user._id });
    const rewards = await Reward.find({ restaurantId: restaurant._id })
      .populate('userId', 'name email')
      .sort({ createdAt: -1 });

    res.json({ success: true, rewards });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get restaurant info
// @route   GET /api/admin/restaurant
exports.getRestaurant = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOne({ ownerId: req.user._id });
    if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found.' });
    res.json({ success: true, restaurant });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update restaurant settings
// @route   PUT /api/admin/restaurant
exports.updateRestaurant = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOneAndUpdate(
      { ownerId: req.user._id },
      { $set: req.body },
      { new: true, runValidators: true }
    );
    res.json({ success: true, message: 'Restaurant updated!', restaurant });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
