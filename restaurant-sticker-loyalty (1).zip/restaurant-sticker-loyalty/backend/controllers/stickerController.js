const StickerCard = require('../models/StickerCard');
const Scan = require('../models/Scan');
const QRCode = require('../models/QRCode');
const Reward = require('../models/Reward');
const Restaurant = require('../models/Restaurant');
const notificationService = require('../services/notificationService');

// @desc    Get active sticker card for user at restaurant
// @route   GET /api/stickers/:restaurantId
exports.getStickerCard = async (req, res) => {
  try {
    const { restaurantId } = req.params;

    let card = await StickerCard.findOne({
      userId: req.user._id,
      restaurantId,
      isExpired: false,
      isCompleted: false
    }).populate('restaurantId', 'name settings address phone');

    if (!card) {
      const restaurant = await Restaurant.findById(restaurantId);
      if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found' });

      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + (restaurant.settings.cardExpiryDays || 30));

      const lastCard = await StickerCard.findOne({ userId: req.user._id, restaurantId }).sort({ cardNumber: -1 });
      const cardNumber = lastCard ? lastCard.cardNumber + 1 : 1;

      card = await StickerCard.create({
        userId: req.user._id,
        restaurantId,
        expiryDate,
        cardNumber
      });
      await card.populate('restaurantId', 'name settings address phone');
    }

    const pendingRewards = await Reward.countDocuments({
      userId: req.user._id,
      restaurantId,
      redeemed: false,
      isExpired: false
    });

    res.json({
      success: true,
      card: {
        ...card.toJSON(),
        pendingRewards
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Process QR scan and add sticker
// @route   POST /api/stickers/scan
exports.processScan = async (req, res) => {
  try {
    const { qrToken } = req.body;

    // Validate QR code
    const qrCode = await QRCode.findOne({ token: qrToken, isActive: true });
    if (!qrCode) {
      return res.status(400).json({ success: false, message: 'Invalid or inactive QR code.' });
    }

    const restaurant = await Restaurant.findById(qrCode.restaurantId);
    if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found.' });

    // Check operating hours
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    const [openH, openM] = restaurant.openingTime.split(':').map(Number);
    const [closeH, closeM] = restaurant.closingTime.split(':').map(Number);
    const openMinutes = openH * 60 + openM;
    const closeMinutes = closeH * 60 + closeM;

    if (currentTime < openMinutes || currentTime > closeMinutes) {
      return res.status(400).json({
        success: false,
        message: `Restaurant is currently closed. Open ${restaurant.openingTime} - ${restaurant.closingTime}.`
      });
    }

    // Check duplicate scan (fraud prevention - same QR within cooldown)
    const cooldownMs = (restaurant.settings.scanCooldownMinutes || 10) * 60 * 1000;
    const recentScan = await Scan.findOne({
      userId: req.user._id,
      qrId: qrCode._id,
      scanTime: { $gte: new Date(Date.now() - cooldownMs) },
      status: 'valid'
    });

    if (recentScan) {
      const minutesAgo = Math.ceil((Date.now() - recentScan.scanTime) / 60000);
      const waitMinutes = (restaurant.settings.scanCooldownMinutes || 10) - minutesAgo;
      return res.status(429).json({
        success: false,
        message: `Duplicate scan detected. Please wait ${waitMinutes} more minute(s).`,
        type: 'duplicate'
      });
    }

    // Get or create active sticker card
    let card = await StickerCard.findOne({
      userId: req.user._id,
      restaurantId: restaurant._id,
      isExpired: false,
      isCompleted: false
    });

    if (!card) {
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + (restaurant.settings.cardExpiryDays || 30));
      const lastCard = await StickerCard.findOne({ userId: req.user._id, restaurantId: restaurant._id }).sort({ cardNumber: -1 });
      card = await StickerCard.create({
        userId: req.user._id,
        restaurantId: restaurant._id,
        expiryDate,
        cardNumber: lastCard ? lastCard.cardNumber + 1 : 1
      });
    }

    const stickersRequired = restaurant.settings.stickersRequired || 7;
    card.stickersCollected = Math.min(card.stickersCollected + 1, stickersRequired);

    let rewardEarned = false;
    let reward = null;

    // Check if card is complete
    if (card.stickersCollected >= stickersRequired) {
      card.isCompleted = true;
      card.completedAt = new Date();

      // Create reward
      reward = await Reward.create({
        userId: req.user._id,
        restaurantId: restaurant._id,
        stickerCardId: card._id,
        rewardDescription: restaurant.settings.rewardDescription || '1 Free Food Item'
      });
      rewardEarned = true;

      // Notify user
      try {
        await notificationService.sendRewardEarnedNotification(req.user, restaurant, reward);
      } catch (e) { console.log('Notification error:', e.message); }
    }

    await card.save();

    // Log scan
    await Scan.create({
      userId: req.user._id,
      restaurantId: restaurant._id,
      qrId: qrCode._id,
      qrToken,
      stickerCardId: card._id,
      scanTime: new Date(),
      stickersAfterScan: card.stickersCollected,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      status: 'valid'
    });

    // Update QR scan count
    await QRCode.findByIdAndUpdate(qrCode._id, { $inc: { scanCount: 1 } });

    res.json({
      success: true,
      message: rewardEarned
        ? '🎉 Congratulations! You earned a FREE reward!'
        : `⭐ Sticker added! ${stickersRequired - card.stickersCollected} more to go!`,
      stickersCollected: card.stickersCollected,
      stickersRequired,
      rewardEarned,
      reward: rewardEarned ? { code: reward.rewardCode, description: reward.rewardDescription } : null,
      card: card.toJSON()
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get scan history for user
// @route   GET /api/stickers/history
exports.getScanHistory = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;

    const scans = await Scan.find({ userId: req.user._id, status: 'valid' })
      .populate('restaurantId', 'name')
      .sort({ scanTime: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    const total = await Scan.countDocuments({ userId: req.user._id, status: 'valid' });

    res.json({ success: true, scans, total, pages: Math.ceil(total / limit), page });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get user rewards
// @route   GET /api/stickers/rewards
exports.getUserRewards = async (req, res) => {
  try {
    const rewards = await Reward.find({ userId: req.user._id })
      .populate('restaurantId', 'name address')
      .sort({ createdAt: -1 });

    res.json({ success: true, rewards });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all sticker cards for user
// @route   GET /api/stickers/cards
exports.getUserCards = async (req, res) => {
  try {
    const cards = await StickerCard.find({ userId: req.user._id })
      .populate('restaurantId', 'name settings')
      .sort({ createdAt: -1 });

    res.json({ success: true, cards });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
