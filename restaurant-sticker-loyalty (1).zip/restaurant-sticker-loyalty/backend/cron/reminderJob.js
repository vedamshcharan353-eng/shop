const cron = require('node-cron');
const StickerCard = require('../models/StickerCard');
const User = require('../models/User');
const Restaurant = require('../models/Restaurant');
const Reward = require('../models/Reward');
const notificationService = require('../services/notificationService');

// Run daily at midnight: expire old cards
const expirationJob = cron.schedule('0 0 * * *', async () => {
  console.log('⏰ [CRON] Running expiration check...');
  try {
    const now = new Date();
    const expiredCards = await StickerCard.find({
      expiryDate: { $lte: now },
      isExpired: false,
      isCompleted: false
    }).populate('userId', 'name email emailNotifications pushNotifications pushSubscription');

    for (const card of expiredCards) {
      card.isExpired = true;
      await card.save();
    }

    console.log(`✅ [CRON] Expired ${expiredCards.length} sticker cards.`);

    // Also expire old rewards (90 days)
    const expiredRewards = await Reward.updateMany(
      { expiryDate: { $lte: now }, redeemed: false, isExpired: false },
      { isExpired: true }
    );
    console.log(`✅ [CRON] Expired ${expiredRewards.modifiedCount} rewards.`);
  } catch (error) {
    console.error('❌ [CRON] Expiration job error:', error.message);
  }
}, { scheduled: false });

// Run every 3 hours: send reminders
const reminderJob = cron.schedule('0 */3 * * *', async () => {
  console.log('⏰ [CRON] Running reminder check...');
  try {
    const now = new Date();

    // Find active cards that need reminders
    const activeCards = await StickerCard.find({
      isExpired: false,
      isCompleted: false,
      expiryDate: { $gte: now }
    }).populate('userId', 'name email emailNotifications pushNotifications pushSubscription')
      .populate('restaurantId', 'name settings');

    let remindersSent = 0;

    for (const card of activeCards) {
      if (!card.userId || !card.restaurantId) continue;

      const msRemaining = card.expiryDate - now;
      const hoursRemaining = msRemaining / (1000 * 60 * 60);
      const daysRemaining = hoursRemaining / 24;

      let shouldSend = false;
      let reminderType = '';
      let timeText = '';

      // Determine if we should send a reminder
      if (hoursRemaining <= 1 && hoursRemaining > 0) {
        reminderType = '1h';
        timeText = 'Last 1 hour';
        shouldSend = true;
      } else if (hoursRemaining <= 3 && hoursRemaining > 1) {
        reminderType = '3h';
        timeText = '3 hours';
        shouldSend = true;
      } else if (daysRemaining <= 1 && daysRemaining > 0) {
        reminderType = '1d';
        timeText = '1 day';
        shouldSend = true;
      } else {
        // Check 3-day intervals: 3, 6, 9, 12, 15, 18, 21, 24, 27 days remaining
        const daysRemainingRounded = Math.round(daysRemaining);
        if (daysRemainingRounded % 3 === 0 && daysRemainingRounded > 0) {
          reminderType = `${daysRemainingRounded}d`;
          timeText = `${daysRemainingRounded} days`;
          shouldSend = true;
        }
      }

      if (!shouldSend) continue;

      // Check if we already sent this reminder type
      const alreadySent = card.remindersSent?.some(r => r.type === reminderType);
      if (alreadySent) continue;

      // Don't remind if they've already collected all stickers
      const stickersRequired = card.restaurantId.settings?.stickersRequired || 7;
      if (card.stickersCollected >= stickersRequired) continue;

      try {
        await notificationService.sendReminderNotification(
          card.userId, card.restaurantId, card, `${timeText} left`
        );

        card.remindersSent = card.remindersSent || [];
        card.remindersSent.push({ sentAt: now, type: reminderType, daysRemaining: daysRemaining });
        card.lastReminderSent = now;
        await card.save();
        remindersSent++;
      } catch (e) {
        console.error(`Reminder error for card ${card._id}:`, e.message);
      }
    }

    console.log(`✅ [CRON] Sent ${remindersSent} reminders.`);
  } catch (error) {
    console.error('❌ [CRON] Reminder job error:', error.message);
  }
}, { scheduled: false });

const startCronJobs = () => {
  expirationJob.start();
  reminderJob.start();
  console.log('✅ Cron jobs started: expiration (daily) + reminders (every 3 hours)');
};

const stopCronJobs = () => {
  expirationJob.stop();
  reminderJob.stop();
};

module.exports = { startCronJobs, stopCronJobs, expirationJob, reminderJob };
