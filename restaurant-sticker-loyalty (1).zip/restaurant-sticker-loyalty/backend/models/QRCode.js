const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const qrCodeSchema = new mongoose.Schema({
  restaurantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: true
  },
  token: {
    type: String,
    unique: true,
    default: () => uuidv4()
  },
  label: {
    type: String,
    trim: true,
    default: 'Table QR'
  },
  tableNumber: {
    type: String,
    trim: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  scanCount: {
    type: Number,
    default: 0
  },
  qrImageUrl: {
    type: String
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('QRCode', qrCodeSchema);
