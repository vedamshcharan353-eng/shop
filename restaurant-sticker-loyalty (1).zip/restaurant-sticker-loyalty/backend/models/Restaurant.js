const mongoose = require('mongoose');

const restaurantSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Restaurant name is required'],
    trim: true
  },
  ownerEmail: {
    type: String,
    required: [true, 'Owner email is required'],
    lowercase: true,
    trim: true
  },
  ownerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  address: {
    type: String,
    default: '16-127, Station Rd, Gandhi Nagar Colony, Shadnagar, Telangana 509216'
  },
  phone: {
    type: String,
    default: '+91 90321 10007'
  },
  openingTime: {
    type: String,
    default: '12:00'
  },
  closingTime: {
    type: String,
    default: '23:30'
  },
  logo: {
    type: String
  },
  isActive: {
    type: Boolean,
    default: true
  },
  settings: {
    stickersRequired: {
      type: Number,
      default: 7
    },
    cardExpiryDays: {
      type: Number,
      default: 30
    },
    scanCooldownMinutes: {
      type: Number,
      default: 10
    },
    rewardDescription: {
      type: String,
      default: '1 Free Food Item of Your Choice'
    }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Restaurant', restaurantSchema);
