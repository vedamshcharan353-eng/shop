const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const rewardSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  restaurantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: true
  },
  stickerCardId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'StickerCard'
  },
  rewardCode: {
    type: String,
    unique: true,
    default: () => uuidv4().substring(0, 8).toUpperCase()
  },
  rewardDescription: {
    type: String,
    default: '1 Free Food Item'
  },
  redeemed: {
    type: Boolean,
    default: false
  },
  redeemedAt: {
    type: Date
  },
  redeemedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  expiryDate: {
    type: Date,
    default: () => new Date(Date.now() + 90 * 24 * 60 * 60 * 1000) // 90 days
  },
  isExpired: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Reward', rewardSchema);
