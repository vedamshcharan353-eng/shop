const mongoose = require('mongoose');

const scanSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  restaurantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: true
  },
  qrId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'QRCode',
    required: true
  },
  qrToken: {
    type: String,
    required: true
  },
  stickerCardId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'StickerCard'
  },
  scanTime: {
    type: Date,
    default: Date.now
  },
  stickersAfterScan: {
    type: Number
  },
  ipAddress: {
    type: String
  },
  userAgent: {
    type: String
  },
  status: {
    type: String,
    enum: ['valid', 'duplicate', 'expired', 'invalid'],
    default: 'valid'
  }
}, {
  timestamps: true
});

// Index for duplicate scan detection
scanSchema.index({ userId: 1, qrId: 1, scanTime: -1 });
scanSchema.index({ userId: 1, restaurantId: 1, scanTime: -1 });

module.exports = mongoose.model('Scan', scanSchema);
