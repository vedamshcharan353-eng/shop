const mongoose = require('mongoose');

const stickerCardSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  restaurantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
    required: true
  },
  stickersCollected: {
    type: Number,
    default: 0,
    min: 0,
    max: 7
  },
  expiryDate: {
    type: Date,
    required: true
  },
  isCompleted: {
    type: Boolean,
    default: false
  },
  isExpired: {
    type: Boolean,
    default: false
  },
  completedAt: {
    type: Date
  },
  cardNumber: {
    type: Number,
    default: 1
  },
  lastReminderSent: {
    type: Date
  },
  remindersSent: [{
    sentAt: Date,
    daysRemaining: Number,
    type: String
  }]
}, {
  timestamps: true
});

// Index for efficient queries
stickerCardSchema.index({ userId: 1, restaurantId: 1 });
stickerCardSchema.index({ expiryDate: 1 });

// Virtual: days remaining
stickerCardSchema.virtual('daysRemaining').get(function() {
  const now = new Date();
  const diff = this.expiryDate - now;
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
});

// Virtual: hours remaining
stickerCardSchema.virtual('hoursRemaining').get(function() {
  const now = new Date();
  const diff = this.expiryDate - now;
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60)));
});

stickerCardSchema.set('toJSON', { virtuals: true });
stickerCardSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('StickerCard', stickerCardSchema);
