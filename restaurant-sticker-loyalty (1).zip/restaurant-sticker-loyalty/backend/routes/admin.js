const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect, adminOnly);

router.get('/analytics', adminController.getAnalytics);
router.get('/restaurant', adminController.getRestaurant);
router.put('/restaurant', adminController.updateRestaurant);
router.post('/qr/generate', adminController.generateQR);
router.get('/qr', adminController.getQRCodes);
router.put('/qr/:id/toggle', adminController.toggleQR);
router.get('/customers', adminController.getCustomers);
router.get('/rewards', adminController.getRewards);
router.put('/rewards/:code/redeem', adminController.redeemReward);

module.exports = router;
