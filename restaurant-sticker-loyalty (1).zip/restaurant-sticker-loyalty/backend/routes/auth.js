const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { protect } = require('../middleware/auth');

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/admin/login', authController.adminLogin);
router.get('/me', protect, authController.getMe);
router.post('/push-subscription', protect, authController.updatePushSubscription);

module.exports = router;
