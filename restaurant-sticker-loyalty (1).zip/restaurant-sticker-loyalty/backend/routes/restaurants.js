const express = require('express');
const router = express.Router();
const Restaurant = require('../models/Restaurant');
const QRCode = require('../models/QRCode');

// Get restaurant info by ID (public)
router.get('/:id', async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.params.id).select('-__v');
    if (!restaurant) return res.status(404).json({ success: false, message: 'Restaurant not found.' });
    res.json({ success: true, restaurant });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Validate QR token (public, for frontend scan page)
router.get('/qr/:token', async (req, res) => {
  try {
    const qr = await QRCode.findOne({ token: req.params.token, isActive: true })
      .populate('restaurantId', 'name address phone openingTime closingTime settings');
    if (!qr) return res.status(404).json({ success: false, message: 'Invalid or inactive QR code.' });
    res.json({ success: true, qr: { token: qr.token, label: qr.label, restaurant: qr.restaurantId } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
