const express = require('express');
const router = express.Router();
const stickerController = require('../controllers/stickerController');
const { protect } = require('../middleware/auth');

router.use(protect);

router.get('/cards', stickerController.getUserCards);
router.get('/history', stickerController.getScanHistory);
router.get('/rewards', stickerController.getUserRewards);
router.post('/scan', stickerController.processScan);
router.get('/:restaurantId', stickerController.getStickerCard);

module.exports = router;
