require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/db');
const { startCronJobs } = require('./cron/reminderJob');

const app = express();

// Connect to database
connectDB();

// Security middleware
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));

// CORS
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { success: false, message: 'Too many requests. Please try again later.' }
});

const scanLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 5,
  message: { success: false, message: 'Too many scan attempts. Please wait.' }
});

app.use('/api/', limiter);
app.use('/api/stickers/scan', scanLimiter);

// Body parser
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/stickers', require('./routes/stickers'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/restaurants', require('./routes/restaurants'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'Restaurant Loyalty API is running! 🍽️',
    timestamp: new Date().toISOString()
  });
});

// Seed admin account (run once)
app.post('/api/seed', async (req, res) => {
  try {
    const User = require('./models/User');
    const Restaurant = require('./models/Restaurant');

    const existingAdmin = await User.findOne({ email: 'admin@restaurant.com' });
    if (existingAdmin) {
      return res.json({ success: false, message: 'Admin already seeded.' });
    }

    const admin = await User.create({
      name: 'Restaurant Admin',
      email: 'admin@restaurant.com',
      password: 'admin123456',
      role: 'admin'
    });

    await Restaurant.create({
      name: 'The Loyalty Kitchen',
      ownerEmail: admin.email,
      ownerId: admin._id,
      address: '16-127, Station Rd, Gandhi Nagar Colony, Shadnagar, Telangana 509216',
      phone: '+91 90321 10007',
      openingTime: '12:00',
      closingTime: '23:30'
    });

    res.json({
      success: true,
      message: 'Admin seeded! Email: admin@restaurant.com | Password: admin123456'
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ success: false, message: 'Route not found.' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Internal server error.' });
});

const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🍽️  Restaurant Sticker Loyalty API`);
  startCronJobs();
});

module.exports = server;
