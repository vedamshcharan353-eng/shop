const nodemailer = require('nodemailer');
const webpush = require('web-push');
const User = require('../models/User');

// Configure email transporter
const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
};

// Configure Web Push
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(
    process.env.VAPID_EMAIL || 'mailto:admin@loyalty.com',
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  );
}

const sendEmail = async (to, subject, html) => {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.log(`📧 [EMAIL MOCK] To: ${to} | Subject: ${subject}`);
    return { mock: true };
  }
  try {
    const transporter = createTransporter();
    const result = await transporter.sendMail({
      from: `"${process.env.EMAIL_FROM_NAME || 'Restaurant Loyalty'}" <${process.env.EMAIL_FROM || process.env.SMTP_USER}>`,
      to,
      subject,
      html
    });
    console.log(`📧 Email sent to ${to}: ${result.messageId}`);
    return result;
  } catch (error) {
    console.error('Email send error:', error.message);
    return null;
  }
};

const sendPushNotification = async (subscription, payload) => {
  if (!process.env.VAPID_PUBLIC_KEY) return null;
  try {
    await webpush.sendNotification(subscription, JSON.stringify(payload));
    return true;
  } catch (error) {
    console.error('Push notification error:', error.message);
    return null;
  }
};

// Email templates
const getReminderEmailTemplate = (userName, restaurantName, stickersCollected, stickersRequired, timeRemaining) => `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px;">
  <div style="max-width: 500px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
    <div style="background: linear-gradient(135deg, #FF6B35, #F7C59F); padding: 30px; text-align: center;">
      <div style="font-size: 48px; margin-bottom: 10px;">⏰</div>
      <h1 style="color: white; margin: 0; font-size: 22px;">Your Stickers Are Expiring!</h1>
      <p style="color: rgba(255,255,255,0.9); margin: 8px 0 0;">${restaurantName}</p>
    </div>
    <div style="padding: 30px;">
      <p style="color: #333; font-size: 16px;">Hi <strong>${userName}</strong>,</p>
      <p style="color: #555; line-height: 1.6;">
        ⚠️ <strong>${timeRemaining}</strong> before your loyalty stickers at <strong>${restaurantName}</strong> expire!
      </p>
      <div style="background: #fff8f0; border: 2px solid #FF6B35; border-radius: 12px; padding: 20px; margin: 20px 0; text-align: center;">
        <div style="font-size: 14px; color: #888; margin-bottom: 10px;">YOUR PROGRESS</div>
        <div style="font-size: 32px; letter-spacing: 4px; margin: 10px 0;">
          ${'⭐'.repeat(stickersCollected)}${'⬜'.repeat(stickersRequired - stickersCollected)}
        </div>
        <div style="font-size: 14px; color: #FF6B35; font-weight: bold;">
          ${stickersCollected} / ${stickersRequired} stickers collected
        </div>
        <div style="font-size: 13px; color: #888; margin-top: 5px;">
          ${stickersRequired - stickersCollected} more for a FREE reward!
        </div>
      </div>
      <div style="text-align: center; margin: 25px 0;">
        <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}" 
           style="background: #FF6B35; color: white; padding: 14px 30px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block;">
          Scan QR Code Now 📷
        </a>
      </div>
      <p style="color: #888; font-size: 12px; text-align: center; margin-top: 20px;">
        Visit us at: 16-127, Station Rd, Gandhi Nagar Colony, Shadnagar, Telangana 509216<br>
        📞 +91 90321 10007 | Hours: 12:00 PM – 11:30 PM
      </p>
    </div>
  </div>
</body>
</html>
`;

const getRewardEmailTemplate = (userName, restaurantName, rewardCode, rewardDescription) => `
<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px;">
  <div style="max-width: 500px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
    <div style="background: linear-gradient(135deg, #FFD700, #FF6B35); padding: 30px; text-align: center;">
      <div style="font-size: 60px; margin-bottom: 10px;">🎉</div>
      <h1 style="color: white; margin: 0; font-size: 24px;">Free Reward Unlocked!</h1>
    </div>
    <div style="padding: 30px; text-align: center;">
      <p style="color: #333; font-size: 16px;">Congratulations <strong>${userName}</strong>!</p>
      <p style="color: #555;">You've collected all 7 stickers at <strong>${restaurantName}</strong>!</p>
      <div style="background: #fff8e7; border: 2px dashed #FFD700; border-radius: 12px; padding: 20px; margin: 20px 0;">
        <div style="font-size: 14px; color: #888; margin-bottom: 5px;">YOUR REWARD CODE</div>
        <div style="font-size: 28px; font-weight: bold; color: #FF6B35; letter-spacing: 4px;">${rewardCode}</div>
        <div style="font-size: 14px; color: #555; margin-top: 10px;">${rewardDescription}</div>
      </div>
      <p style="color: #888; font-size: 13px;">Show this code to the restaurant staff to redeem your free reward!</p>
      <p style="color: #888; font-size: 12px; margin-top: 20px;">
        Visit us at: 16-127, Station Rd, Gandhi Nagar Colony, Shadnagar, Telangana 509216
      </p>
    </div>
  </div>
</body>
</html>
`;

exports.sendReminderNotification = async (user, restaurant, card, timeRemainingText) => {
  const subject = `⏰ ${timeRemainingText} before your ${restaurant.name} stickers expire!`;
  const html = getReminderEmailTemplate(
    user.name, restaurant.name,
    card.stickersCollected, restaurant.settings?.stickersRequired || 7,
    timeRemainingText
  );

  if (user.emailNotifications) {
    await sendEmail(user.email, subject, html);
  }

  if (user.pushNotifications && user.pushSubscription) {
    await sendPushNotification(user.pushSubscription, {
      title: `⏰ ${restaurant.name} - Stickers Expiring!`,
      body: `${timeRemainingText} left! You have ${card.stickersCollected}/${restaurant.settings?.stickersRequired || 7} stickers.`,
      icon: '/logo192.png',
      url: `${process.env.FRONTEND_URL}/dashboard`
    });
  }
};

exports.sendRewardEarnedNotification = async (user, restaurant, reward) => {
  const subject = `🎉 You earned a FREE reward at ${restaurant.name}!`;
  const html = getRewardEmailTemplate(user.name, restaurant.name, reward.rewardCode, reward.rewardDescription);

  if (user.emailNotifications) {
    await sendEmail(user.email, subject, html);
  }

  if (user.pushNotifications && user.pushSubscription) {
    await sendPushNotification(user.pushSubscription, {
      title: `🎉 Free Reward at ${restaurant.name}!`,
      body: `Your reward code: ${reward.rewardCode}`,
      icon: '/logo192.png',
      url: `${process.env.FRONTEND_URL}/rewards`
    });
  }
};

module.exports = {
  sendEmail,
  sendPushNotification,
  sendReminderNotification: exports.sendReminderNotification,
  sendRewardEarnedNotification: exports.sendRewardEarnedNotification
};
