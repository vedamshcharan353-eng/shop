import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';

// Customer Pages
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import ScanPage from './pages/ScanPage';
import RewardsPage from './pages/RewardsPage';
import HistoryPage from './pages/HistoryPage';

// Admin Pages
import AdminLoginPage from './pages/admin/AdminLoginPage';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import QRGeneratorPage from './pages/admin/QRGeneratorPage';
import CustomersPage from './pages/admin/CustomersPage';
import AdminRewardsPage from './pages/admin/AdminRewardsPage';
import AnalyticsPage from './pages/admin/AnalyticsPage';

import LoadingSpinner from './components/LoadingSpinner';

const PrivateRoute = ({ children, adminOnly = false }) => {
  const { user, loading } = useAuth();
  if (loading) return <LoadingSpinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== 'admin') return <Navigate to="/dashboard" replace />;
  return children;
};

const PublicRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <LoadingSpinner />;
  if (user) return <Navigate to={user.role === 'admin' ? '/admin/dashboard' : '/dashboard'} replace />;
  return children;
};

function AppRoutes() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
      <Route path="/register" element={<PublicRoute><RegisterPage /></PublicRoute>} />
      <Route path="/admin/login" element={<PublicRoute><AdminLoginPage /></PublicRoute>} />

      {/* Scan page (accessible when logged in, redirect to login with return url) */}
      <Route path="/scan/:token" element={<PrivateRoute><ScanPage /></PrivateRoute>} />

      {/* Customer routes */}
      <Route path="/dashboard" element={<PrivateRoute><DashboardPage /></PrivateRoute>} />
      <Route path="/rewards" element={<PrivateRoute><RewardsPage /></PrivateRoute>} />
      <Route path="/history" element={<PrivateRoute><HistoryPage /></PrivateRoute>} />

      {/* Admin routes */}
      <Route path="/admin/dashboard" element={<PrivateRoute adminOnly><AdminDashboardPage /></PrivateRoute>} />
      <Route path="/admin/qr" element={<PrivateRoute adminOnly><QRGeneratorPage /></PrivateRoute>} />
      <Route path="/admin/customers" element={<PrivateRoute adminOnly><CustomersPage /></PrivateRoute>} />
      <Route path="/admin/rewards" element={<PrivateRoute adminOnly><AdminRewardsPage /></PrivateRoute>} />
      <Route path="/admin/analytics" element={<PrivateRoute adminOnly><AnalyticsPage /></PrivateRoute>} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 4000,
            style: {
              borderRadius: '12px',
              background: '#1a1a2e',
              color: '#fff',
              fontSize: '14px',
              fontFamily: "'Plus Jakarta Sans', sans-serif"
            },
            success: { iconTheme: { primary: '#FF6B35', secondary: '#fff' } },
            error: { iconTheme: { primary: '#ef4444', secondary: '#fff' } }
          }}
        />
      </Router>
    </AuthProvider>
  );
}

export default App;
