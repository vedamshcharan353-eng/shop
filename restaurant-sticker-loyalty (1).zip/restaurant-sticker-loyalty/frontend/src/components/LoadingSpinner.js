import React from 'react';

const LoadingSpinner = ({ message = 'Loading...' }) => (
  <div style={{
    minHeight: '100vh', display: 'flex', flexDirection: 'column',
    alignItems: 'center', justifyContent: 'center', gap: '16px',
    background: '#faf9f7'
  }}>
    <div style={{
      width: '48px', height: '48px', border: '4px solid #f0ebe3',
      borderTopColor: '#FF6B35', borderRadius: '50%',
      animation: 'spin 0.8s linear infinite'
    }} />
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    <p style={{ color: '#9ca3af', fontSize: '14px', fontWeight: 500 }}>{message}</p>
  </div>
);

export default LoadingSpinner;
