import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const CustomerNav = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout } = useAuth();

  const items = [
    { path: '/dashboard', icon: HomeIcon, label: 'Home' },
    { path: '/scan/demo', icon: ScanIcon, label: 'Scan' },
    { path: '/rewards', icon: GiftIcon, label: 'Rewards' },
    { path: '/history', icon: HistoryIcon, label: 'History' },
  ];

  return (
    <nav className="bottom-nav">
      {items.map(({ path, icon: Icon, label }) => (
        <button
          key={path}
          className={`nav-item ${location.pathname === path || (path !== '/dashboard' && location.pathname.startsWith(path.split('/')[1] === 'scan' ? '/scan' : path)) ? 'active' : ''}`}
          onClick={() => path === '/scan/demo' ? navigate('/scan/demo') : navigate(path)}
        >
          <Icon />
          <span>{label}</span>
        </button>
      ))}
      <button className="nav-item" onClick={logout}>
        <LogoutIcon />
        <span>Logout</span>
      </button>
    </nav>
  );
};

const AdminNav = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout } = useAuth();

  const items = [
    { path: '/admin/dashboard', icon: HomeIcon, label: 'Home' },
    { path: '/admin/qr', icon: QRIcon, label: 'QR Codes' },
    { path: '/admin/customers', icon: UsersIcon, label: 'Customers' },
    { path: '/admin/rewards', icon: GiftIcon, label: 'Rewards' },
    { path: '/admin/analytics', icon: ChartIcon, label: 'Analytics' },
  ];

  return (
    <nav className="bottom-nav">
      {items.map(({ path, icon: Icon, label }) => (
        <button
          key={path}
          className={`nav-item ${location.pathname === path ? 'active' : ''}`}
          onClick={() => navigate(path)}
        >
          <Icon />
          <span style={{ fontSize: '9px' }}>{label}</span>
        </button>
      ))}
      <button className="nav-item" onClick={logout}>
        <LogoutIcon />
        <span style={{ fontSize: '9px' }}>Logout</span>
      </button>
    </nav>
  );
};

// SVG Icons
const HomeIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;
const ScanIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="4 7 4 4 7 4"/><polyline points="17 4 20 4 20 7"/><polyline points="20 17 20 20 17 20"/><polyline points="7 20 4 20 4 17"/><line x1="7" y1="12" x2="17" y2="12"/></svg>;
const GiftIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><path d="M12 22V7m0 0H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7zm0 0h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z"/></svg>;
const HistoryIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>;
const LogoutIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>;
const QRIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="3" height="3"/><rect x="18" y="14" width="3" height="3"/><rect x="14" y="18" width="3" height="3"/><rect x="18" y="18" width="3" height="3"/></svg>;
const UsersIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>;
const ChartIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>;

export { CustomerNav, AdminNav };
