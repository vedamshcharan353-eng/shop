import React, { useEffect, useState } from 'react';

const StickerCard = ({ stickersCollected = 0, stickersRequired = 7, expiryDate, restaurantName, isAnimated = false }) => {
  const [animatedStickers, setAnimatedStickers] = useState(isAnimated ? 0 : stickersCollected);

  useEffect(() => {
    if (!isAnimated) {
      setAnimatedStickers(stickersCollected);
      return;
    }
    let count = 0;
    const interval = setInterval(() => {
      count++;
      setAnimatedStickers(count);
      if (count >= stickersCollected) clearInterval(interval);
    }, 150);
    return () => clearInterval(interval);
  }, [stickersCollected, isAnimated]);

  const isComplete = stickersCollected >= stickersRequired;
  const daysRemaining = expiryDate
    ? Math.max(0, Math.ceil((new Date(expiryDate) - new Date()) / (1000 * 60 * 60 * 24)))
    : 30;
  const urgency = daysRemaining <= 3 ? 'danger' : daysRemaining <= 7 ? 'warning' : 'ok';
  const progressPct = (stickersCollected / stickersRequired) * 100;

  return (
    <div style={{
      background: isComplete
        ? 'linear-gradient(135deg, #1a1a2e, #0f3460)'
        : 'linear-gradient(135deg, #1a1a2e, #16213e)',
      borderRadius: '20px',
      padding: '24px',
      color: 'white',
      position: 'relative',
      overflow: 'hidden',
      boxShadow: isComplete
        ? '0 8px 40px rgba(255,215,0,0.3)'
        : '0 8px 40px rgba(26,26,46,0.3)'
    }}>
      {/* Decorative circles */}
      <div style={{
        position: 'absolute', top: -40, right: -40,
        width: 150, height: 150, borderRadius: '50%',
        background: 'rgba(255,107,53,0.15)', pointerEvents: 'none'
      }} />
      <div style={{
        position: 'absolute', bottom: -30, left: -30,
        width: 100, height: 100, borderRadius: '50%',
        background: 'rgba(255,215,0,0.1)', pointerEvents: 'none'
      }} />

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
        <div>
          <div style={{ fontSize: '11px', opacity: 0.6, textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '4px' }}>
            LOYALTY CARD
          </div>
          <div style={{ fontSize: '16px', fontWeight: 700 }}>{restaurantName || 'Restaurant'}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '11px', opacity: 0.6, marginBottom: '2px' }}>EXPIRES IN</div>
          <div style={{
            fontSize: '14px', fontWeight: 700,
            color: urgency === 'danger' ? '#ef4444' : urgency === 'warning' ? '#f59e0b' : '#34d399'
          }}>
            {daysRemaining}d left
          </div>
        </div>
      </div>

      {/* Sticker slots */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${stickersRequired}, 1fr)`,
        gap: '8px',
        marginBottom: '20px'
      }}>
        {Array.from({ length: stickersRequired }, (_, i) => (
          <div
            key={i}
            className={i < animatedStickers ? 'sticker-filled' : ''}
            style={{
              aspectRatio: '1',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: i < stickersRequired - 1 ? '20px' : '22px',
              background: i < animatedStickers
                ? 'radial-gradient(circle, rgba(255,215,0,0.3), rgba(255,107,53,0.2))'
                : 'rgba(255,255,255,0.08)',
              border: i < animatedStickers
                ? '2px solid rgba(255,215,0,0.6)'
                : '2px dashed rgba(255,255,255,0.2)',
              transition: 'all 0.3s',
              animationDelay: `${i * 0.1}s`
            }}
          >
            {i < animatedStickers ? '⭐' : ''}
          </div>
        ))}
      </div>

      {/* Progress bar */}
      <div style={{ marginBottom: '16px' }}>
        <div style={{ height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '3px', overflow: 'hidden' }}>
          <div style={{
            height: '100%',
            width: `${progressPct}%`,
            background: isComplete
              ? 'linear-gradient(90deg, #FFD700, #FF6B35)'
              : 'linear-gradient(90deg, #FF6B35, #F7C59F)',
            borderRadius: '3px',
            transition: 'width 0.5s ease'
          }} />
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: '13px', opacity: 0.7 }}>
          {isComplete
            ? '🎉 Card Complete!'
            : `${stickersCollected}/${stickersRequired} stickers`}
        </div>
        {!isComplete && (
          <div style={{
            fontSize: '12px',
            background: 'rgba(255,107,53,0.2)',
            border: '1px solid rgba(255,107,53,0.4)',
            borderRadius: '20px',
            padding: '4px 12px',
            color: '#F7C59F'
          }}>
            {stickersRequired - stickersCollected} more for FREE reward 🎁
          </div>
        )}
        {isComplete && (
          <div style={{
            fontSize: '12px',
            background: 'rgba(255,215,0,0.2)',
            border: '1px solid rgba(255,215,0,0.4)',
            borderRadius: '20px',
            padding: '4px 12px',
            color: '#FFD700'
          }}>
            Reward Ready! 🏆
          </div>
        )}
      </div>
    </div>
  );
};

export default StickerCard;
