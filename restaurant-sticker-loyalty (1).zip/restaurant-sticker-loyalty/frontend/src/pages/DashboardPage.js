import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { stickerAPI } from '../services/api';
import { CustomerNav } from '../components/Navigation';
import StickerCard from '../components/StickerCard';
import toast from 'react-hot-toast';

const DashboardPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cards, setCards] = useState([]);
  const [rewards, setRewards] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [cardsRes, rewardsRes] = await Promise.all([
          stickerAPI.getUserCards(),
          stickerAPI.getUserRewards()
        ]);
        setCards(cardsRes.cards || []);
        setRewards(rewardsRes.rewards?.filter(r => !r.redeemed && !r.isExpired) || []);
      } catch (err) {
        toast.error('Failed to load your cards');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const activeCards = cards.filter(c => !c.isExpired && !c.isCompleted);
  const completedCards = cards.filter(c => c.isCompleted);
  const pendingRewards = rewards.length;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="app-container" style={{ background: '#faf9f7', paddingBottom: '100px' }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px 32px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '13px', margin: '0 0 4px' }}>{greeting} 👋</p>
            <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>{user?.name}</h1>
          </div>
          <div style={{ textAlign: 'right' }}>
            {pendingRewards > 0 && (
              <div className="pulse-animation" style={{
                background: '#FF6B35', color: 'white', borderRadius: '20px',
                padding: '6px 14px', fontSize: '13px', fontWeight: 700
              }}>
                🎁 {pendingRewards} Reward{pendingRewards > 1 ? 's' : ''} Ready!
              </div>
            )}
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
          {[
            { label: 'Active Cards', value: activeCards.length, emoji: '🎴' },
            { label: 'Completed', value: completedCards.length, emoji: '✅' },
            { label: 'Rewards', value: pendingRewards, emoji: '🏆' }
          ].map(({ label, value, emoji }) => (
            <div key={label} style={{
              flex: 1, background: 'rgba(255,255,255,0.1)', borderRadius: '12px',
              padding: '12px', textAlign: 'center'
            }}>
              <div style={{ fontSize: '20px' }}>{emoji}</div>
              <div style={{ color: 'white', fontWeight: 800, fontSize: '18px' }}>{value}</div>
              <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: '10px' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '24px 20px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#9ca3af' }}>
            <div style={{ fontSize: '40px', marginBottom: '8px' }}>⏳</div>
            <p>Loading your cards...</p>
          </div>
        ) : (
          <>
            {/* Pending Rewards Alert */}
            {pendingRewards > 0 && (
              <div style={{
                background: 'linear-gradient(135deg, #FFD700, #FF6B35)',
                borderRadius: '16px', padding: '16px 20px',
                marginBottom: '24px', display: 'flex',
                alignItems: 'center', justifyContent: 'space-between',
                cursor: 'pointer'
              }} onClick={() => navigate('/rewards')}>
                <div>
                  <div style={{ color: 'white', fontWeight: 800, fontSize: '16px' }}>🎉 You have free rewards!</div>
                  <div style={{ color: 'rgba(255,255,255,0.85)', fontSize: '13px', marginTop: '2px' }}>
                    {pendingRewards} reward{pendingRewards > 1 ? 's' : ''} waiting to be redeemed
                  </div>
                </div>
                <div style={{ color: 'white', fontSize: '24px' }}>→</div>
              </div>
            )}

            {/* Active Cards */}
            {activeCards.length === 0 ? (
              <div style={{
                textAlign: 'center', padding: '40px 24px',
                background: 'white', borderRadius: '20px',
                boxShadow: '0 4px 24px rgba(0,0,0,0.06)', marginBottom: '24px'
              }}>
                <div style={{ fontSize: '60px', marginBottom: '16px' }}>📷</div>
                <h3 style={{ fontWeight: 800, marginBottom: '8px' }}>No active sticker card</h3>
                <p style={{ color: '#9ca3af', fontSize: '14px', marginBottom: '20px' }}>
                  Scan a restaurant QR code to start collecting stickers!
                </p>
                <button className="btn-primary" onClick={() => navigate('/scan/demo')}>
                  Scan QR Code 📷
                </button>
              </div>
            ) : (
              <div>
                <h2 style={{ fontSize: '18px', fontWeight: 800, marginBottom: '16px' }}>Your Cards</h2>
                {activeCards.map(card => (
                  <div key={card._id} style={{ marginBottom: '16px' }}>
                    <StickerCard
                      stickersCollected={card.stickersCollected}
                      stickersRequired={card.restaurantId?.settings?.stickersRequired || 7}
                      expiryDate={card.expiryDate}
                      restaurantName={card.restaurantId?.name}
                      isAnimated={true}
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Scan button */}
            <button
              className="btn-primary"
              onClick={() => navigate('/scan/demo')}
              style={{ background: 'linear-gradient(135deg, #FF6B35, #e55a28)', marginTop: '8px' }}
            >
              <span style={{ fontSize: '20px' }}>📷</span> Scan QR Code
            </button>

            {/* Recent completed cards */}
            {completedCards.length > 0 && (
              <div style={{ marginTop: '24px' }}>
                <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '12px', color: '#6b7280' }}>
                  Completed Cards
                </h3>
                {completedCards.slice(0, 2).map(card => (
                  <div key={card._id} style={{
                    background: 'white', borderRadius: '12px', padding: '16px',
                    marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '12px',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
                  }}>
                    <div style={{ fontSize: '32px' }}>✅</div>
                    <div>
                      <div style={{ fontWeight: 700 }}>{card.restaurantId?.name}</div>
                      <div style={{ fontSize: '12px', color: '#9ca3af' }}>
                        Card #{card.cardNumber} • Completed {new Date(card.completedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <CustomerNav />
    </div>
  );
};

export default DashboardPage;
