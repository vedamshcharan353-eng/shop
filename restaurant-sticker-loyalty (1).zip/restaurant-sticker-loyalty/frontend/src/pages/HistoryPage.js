import React, { useState, useEffect } from 'react';
import { stickerAPI } from '../services/api';
import { CustomerNav } from '../components/Navigation';
import toast from 'react-hot-toast';

const HistoryPage = () => {
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    stickerAPI.getScanHistory()
      .then(res => { setScans(res.scans || []); setTotal(res.total || 0); })
      .catch(() => toast.error('Failed to load history'))
      .finally(() => setLoading(false));
  }, []);

  const formatTime = (date) => {
    const d = new Date(date);
    const now = new Date();
    const diff = now - d;
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  const formatDateTime = (date) => new Date(date).toLocaleString('en-IN', {
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
  });

  return (
    <div className="app-container" style={{ background: '#faf9f7', paddingBottom: '100px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px'
      }}>
        <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>📋 Scan History</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', margin: '8px 0 0' }}>
          {total} total scans
        </p>
      </div>

      <div style={{ padding: '24px 20px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
            <div style={{ fontSize: '40px' }}>⏳</div>
            <p>Loading history...</p>
          </div>
        ) : scans.length === 0 ? (
          <div style={{
            textAlign: 'center', padding: '48px 24px',
            background: 'white', borderRadius: '20px',
            boxShadow: '0 4px 24px rgba(0,0,0,0.06)'
          }}>
            <div style={{ fontSize: '64px', marginBottom: '16px' }}>📭</div>
            <h3 style={{ fontWeight: 800, marginBottom: '8px' }}>No scans yet</h3>
            <p style={{ color: '#9ca3af', fontSize: '14px' }}>
              Your scan history will appear here after your first QR scan
            </p>
          </div>
        ) : (
          <div>
            {scans.map((scan, i) => (
              <div key={scan._id} style={{
                background: 'white', borderRadius: '12px', padding: '16px',
                marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '12px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
              }}>
                <div style={{
                  width: '44px', height: '44px', borderRadius: '50%', flexShrink: 0,
                  background: 'linear-gradient(135deg, #FF6B35, #F7C59F)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '20px'
                }}>
                  ⭐
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: '15px' }}>
                    {scan.restaurantId?.name || 'Restaurant'}
                  </div>
                  <div style={{ fontSize: '12px', color: '#9ca3af', marginTop: '2px' }}>
                    {formatDateTime(scan.scanTime)}
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: '#FF6B35' }}>
                    +1 sticker
                  </div>
                  <div style={{ fontSize: '11px', color: '#9ca3af' }}>
                    {formatTime(scan.scanTime)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <CustomerNav />
    </div>
  );
};

export default HistoryPage;
