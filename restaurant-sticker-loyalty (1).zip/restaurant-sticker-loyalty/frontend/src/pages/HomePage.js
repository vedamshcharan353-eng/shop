import React from 'react';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="app-container" style={{ background: '#faf9f7', minHeight: '100vh' }}>
      {/* Hero */}
      <div style={{
        background: 'linear-gradient(160deg, #1a1a2e 0%, #0f3460 60%, #16213e 100%)',
        padding: '48px 24px 56px',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{ position: 'absolute', top: -60, right: -60, width: 200, height: 200, borderRadius: '50%', background: 'rgba(255,107,53,0.15)' }} />
        <div style={{ position: 'absolute', bottom: -40, left: -40, width: 150, height: 150, borderRadius: '50%', background: 'rgba(255,215,0,0.1)' }} />

        <div className="float-animation" style={{ fontSize: '64px', marginBottom: '16px' }}>🍽️</div>
        <h1 style={{
          color: 'white', margin: '0 0 8px', fontSize: '32px', fontWeight: 800,
          fontFamily: "'Fraunces', serif", lineHeight: 1.2
        }}>
          Loyalty<br /><span style={{ color: '#FF6B35' }}>Stickers</span>
        </h1>
        <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '16px', margin: '0 0 32px', lineHeight: 1.5 }}>
          Collect 7 stickers, earn a<br />FREE meal at your favourite spot!
        </p>

        {/* Sample card preview */}
        <div style={{
          background: 'rgba(255,255,255,0.08)',
          backdropFilter: 'blur(10px)',
          borderRadius: '16px',
          padding: '16px',
          border: '1px solid rgba(255,255,255,0.1)',
          marginBottom: '32px'
        }}>
          <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', marginBottom: '8px' }}>
            {['⭐','⭐','⭐','⬜','⬜','⬜','⬜'].map((s, i) => (
              <span key={i} style={{ fontSize: '22px' }}>{s}</span>
            ))}
          </div>
          <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px', margin: 0 }}>3 more stickers until your FREE reward!</p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <button className="btn-primary" onClick={() => navigate('/register')}>
            Get Started Free 🚀
          </button>
          <button className="btn-secondary" style={{ border: '2px solid rgba(255,255,255,0.3)', color: 'white' }}
            onClick={() => navigate('/login')}>
            I have an account
          </button>
        </div>
      </div>

      {/* Features */}
      <div style={{ padding: '32px 24px' }}>
        <h2 style={{ fontSize: '20px', fontWeight: 800, marginBottom: '20px', textAlign: 'center' }}>How It Works</h2>

        {[
          { emoji: '📷', title: 'Scan QR Code', desc: 'Scan the restaurant QR code after each purchase to earn a sticker' },
          { emoji: '⭐', title: 'Collect Stickers', desc: 'Fill your card with 7 stickers. Card resets after 30 days if incomplete' },
          { emoji: '🎁', title: 'Earn Rewards', desc: 'Get 1 FREE food item once your card is complete!' },
        ].map(({ emoji, title, desc }) => (
          <div key={title} style={{
            display: 'flex', gap: '16px', alignItems: 'flex-start',
            padding: '16px', background: 'white', borderRadius: '16px',
            marginBottom: '12px', boxShadow: '0 2px 12px rgba(0,0,0,0.06)'
          }}>
            <div style={{ fontSize: '36px', flexShrink: 0 }}>{emoji}</div>
            <div>
              <div style={{ fontWeight: 700, marginBottom: '4px' }}>{title}</div>
              <div style={{ fontSize: '14px', color: '#6b7280', lineHeight: 1.5 }}>{desc}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Restaurant info */}
      <div style={{ margin: '0 24px 32px', padding: '20px', background: '#fff5f0', borderRadius: '16px', border: '1px solid #ffe4d4' }}>
        <div style={{ fontWeight: 700, marginBottom: '12px', color: '#FF6B35' }}>📍 Visit Us</div>
        <p style={{ margin: '0 0 8px', fontSize: '14px', color: '#555', lineHeight: 1.5 }}>
          16-127, Station Rd, Gandhi Nagar Colony,<br />Shadnagar, Telangana 509216
        </p>
        <p style={{ margin: '0 0 4px', fontSize: '14px', color: '#555' }}>📞 +91 90321 10007</p>
        <p style={{ margin: 0, fontSize: '14px', color: '#555' }}>🕐 12:00 PM – 11:30 PM</p>
      </div>

      <div style={{ textAlign: 'center', padding: '0 24px 32px' }}>
        <button style={{
          background: 'none', border: 'none', color: '#9ca3af',
          fontSize: '13px', cursor: 'pointer', textDecoration: 'underline'
        }} onClick={() => navigate('/admin/login')}>
          Restaurant Admin Login →
        </button>
      </div>
    </div>
  );
};

export default HomePage;
