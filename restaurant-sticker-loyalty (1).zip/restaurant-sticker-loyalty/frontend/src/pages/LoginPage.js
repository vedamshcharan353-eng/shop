import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import toast from 'react-hot-toast';

const LoginPage = () => {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authAPI.login(form);
      login(res.token, res.user);
      toast.success(`Welcome back, ${res.user.name}! 👋`);
      navigate(res.user.role === 'admin' ? '/admin/dashboard' : '/dashboard');
    } catch (err) {
      toast.error(err.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container" style={{ minHeight: '100vh', background: '#faf9f7' }}>
      <div style={{
        background: 'linear-gradient(160deg, #1a1a2e, #0f3460)',
        padding: '48px 24px 40px',
        textAlign: 'center',
        borderRadius: '0 0 32px 32px'
      }}>
        <div style={{ fontSize: '48px', marginBottom: '12px' }}>👋</div>
        <h1 style={{ color: 'white', margin: 0, fontSize: '26px', fontWeight: 800 }}>Welcome Back!</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', margin: '8px 0 0', fontSize: '14px' }}>Sign in to see your stickers</p>
      </div>

      <div style={{ padding: '32px 24px' }}>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label className="input-label">Email Address</label>
            <input
              type="email"
              className="input-field"
              placeholder="you@example.com"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="input-label">Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="Enter your password"
              value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })}
              required
            />
          </div>
          <button type="submit" className="btn-primary" disabled={loading} style={{ marginTop: '8px' }}>
            {loading ? 'Signing in...' : 'Sign In 🔑'}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '24px' }}>
          <p style={{ color: '#9ca3af', fontSize: '14px' }}>
            Don't have an account?{' '}
            <Link to="/register" style={{ color: '#FF6B35', fontWeight: 700, textDecoration: 'none' }}>
              Sign up free
            </Link>
          </p>
        </div>

        <div style={{ marginTop: '32px', padding: '16px', background: '#f0f0f0', borderRadius: '12px' }}>
          <p style={{ margin: 0, fontSize: '12px', color: '#888', textAlign: 'center' }}>
            <strong>Demo Customer:</strong> demo@customer.com / demo123456<br />
            Run <code>/api/seed</code> to create admin account
          </p>
        </div>

        <div style={{ textAlign: 'center', marginTop: '16px' }}>
          <Link to="/" style={{ color: '#9ca3af', fontSize: '13px' }}>← Back to home</Link>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
