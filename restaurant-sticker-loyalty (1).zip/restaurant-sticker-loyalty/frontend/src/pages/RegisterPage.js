import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import toast from 'react-hot-toast';

const RegisterPage = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    try {
      const res = await authAPI.register(form);
      login(res.token, res.user);
      toast.success('Account created! Welcome! 🎉');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container" style={{ minHeight: '100vh', background: '#faf9f7' }}>
      <div style={{
        background: 'linear-gradient(160deg, #1a1a2e, #0f3460)',
        padding: '48px 24px 40px',
        textAlign: 'center',
        borderRadius: '0 0 32px 32px'
      }}>
        <div style={{ fontSize: '48px', marginBottom: '12px' }}>🌟</div>
        <h1 style={{ color: 'white', margin: 0, fontSize: '26px', fontWeight: 800 }}>Create Account</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', margin: '8px 0 0', fontSize: '14px' }}>Start earning stickers today!</p>
      </div>

      <div style={{ padding: '32px 24px' }}>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label className="input-label">Full Name</label>
            <input
              type="text"
              className="input-field"
              placeholder="John Doe"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="input-label">Email Address</label>
            <input
              type="email"
              className="input-field"
              placeholder="you@example.com"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="input-label">Phone (optional)</label>
            <input
              type="tel"
              className="input-field"
              placeholder="+91 98765 43210"
              value={form.phone}
              onChange={e => setForm({ ...form, phone: e.target.value })}
            />
          </div>
          <div>
            <label className="input-label">Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="Min. 6 characters"
              value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })}
              required
            />
          </div>
          <button type="submit" className="btn-primary" disabled={loading} style={{ marginTop: '8px' }}>
            {loading ? 'Creating account...' : 'Create Account 🚀'}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '24px' }}>
          <p style={{ color: '#9ca3af', fontSize: '14px' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ color: '#FF6B35', fontWeight: 700, textDecoration: 'none' }}>
              Sign in
            </Link>
          </p>
        </div>
        <div style={{ textAlign: 'center', marginTop: '8px' }}>
          <Link to="/" style={{ color: '#9ca3af', fontSize: '13px' }}>← Back to home</Link>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
