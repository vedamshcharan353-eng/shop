import React, { useState, useEffect } from 'react';
import { stickerAPI } from '../services/api';
import { CustomerNav } from '../components/Navigation';
import toast from 'react-hot-toast';

const RewardsPage = () => {
  const [rewards, setRewards] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    stickerAPI.getUserRewards()
      .then(res => setRewards(res.rewards || []))
      .catch(() => toast.error('Failed to load rewards'))
      .finally(() => setLoading(false));
  }, []);

  const pending = rewards.filter(r => !r.redeemed && !r.isExpired);
  const redeemed = rewards.filter(r => r.redeemed);
  const expired = rewards.filter(r => r.isExpired && !r.redeemed);

  const copyCode = (code) => {
    navigator.clipboard?.writeText(code);
    toast.success('Code copied!');
  };

  return (
    <div className="app-container" style={{ background: '#faf9f7', paddingBottom: '100px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px'
      }}>
        <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>🏆 My Rewards</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', margin: '8px 0 0' }}>
          {pending.length} reward{pending.length !== 1 ? 's' : ''} ready to redeem
        </p>
      </div>

      <div style={{ padding: '24px 20px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
            <div style={{ fontSize: '40px' }}>⏳</div>
            <p>Loading rewards...</p>
          </div>
        ) : rewards.length === 0 ? (
          <div style={{
            textAlign: 'center', padding: '48px 24px',
            background: 'white', borderRadius: '20px',
            boxShadow: '0 4px 24px rgba(0,0,0,0.06)'
          }}>
            <div style={{ fontSize: '64px', marginBottom: '16px' }}>🎁</div>
            <h3 style={{ fontWeight: 800, marginBottom: '8px' }}>No rewards yet</h3>
            <p style={{ color: '#9ca3af', fontSize: '14px' }}>
              Collect 7 stickers to earn your first free reward!
            </p>
          </div>
        ) : (
          <>
            {/* Pending rewards */}
            {pending.length > 0 && (
              <div style={{ marginBottom: '24px' }}>
                <h2 style={{ fontSize: '16px', fontWeight: 800, marginBottom: '12px', color: '#FF6B35' }}>
                  🎉 Ready to Redeem
                </h2>
                {pending.map(reward => (
                  <div key={reward._id} style={{
                    background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
                    borderRadius: '20px', padding: '24px', marginBottom: '16px',
                    color: 'white', position: 'relative', overflow: 'hidden'
                  }}>
                    <div style={{ position: 'absolute', top: -20, right: -20, width: 100, height: 100, borderRadius: '50%', background: 'rgba(255,215,0,0.15)' }} />
                    <div style={{ fontSize: '11px', opacity: 0.6, marginBottom: '4px', textTransform: 'uppercase' }}>FREE REWARD</div>
                    <div style={{ fontSize: '18px', fontWeight: 800, marginBottom: '4px' }}>{reward.rewardDescription}</div>
                    <div style={{ fontSize: '13px', opacity: 0.7, marginBottom: '20px' }}>{reward.restaurantId?.name}</div>

                    <div style={{
                      background: 'rgba(255,215,0,0.15)', border: '2px dashed rgba(255,215,0,0.5)',
                      borderRadius: '12px', padding: '16px', textAlign: 'center', cursor: 'pointer'
                    }} onClick={() => copyCode(reward.rewardCode)}>
                      <div style={{ fontSize: '11px', opacity: 0.6, marginBottom: '6px' }}>TAP TO COPY CODE</div>
                      <div style={{ fontSize: '28px', fontWeight: 800, letterSpacing: '4px', color: '#FFD700' }}>
                        {reward.rewardCode}
                      </div>
                    </div>

                    <div style={{ marginTop: '12px', fontSize: '12px', opacity: 0.6, textAlign: 'center' }}>
                      Show this code to the staff • Expires {new Date(reward.expiryDate).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Redeemed rewards */}
            {redeemed.length > 0 && (
              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ fontSize: '15px', fontWeight: 700, marginBottom: '12px', color: '#6b7280' }}>
                  ✅ Redeemed
                </h3>
                {redeemed.map(reward => (
                  <div key={reward._id} style={{
                    background: 'white', borderRadius: '12px', padding: '16px',
                    marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '12px',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)', opacity: 0.7
                  }}>
                    <div style={{ fontSize: '28px' }}>✅</div>
                    <div>
                      <div style={{ fontWeight: 600 }}>{reward.rewardDescription}</div>
                      <div style={{ fontSize: '12px', color: '#9ca3af' }}>
                        Redeemed {new Date(reward.redeemedAt).toLocaleDateString()} • {reward.rewardCode}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Expired */}
            {expired.length > 0 && (
              <div>
                <h3 style={{ fontSize: '15px', fontWeight: 700, marginBottom: '12px', color: '#6b7280' }}>
                  ⏰ Expired
                </h3>
                {expired.map(reward => (
                  <div key={reward._id} style={{
                    background: '#f9fafb', borderRadius: '12px', padding: '16px',
                    marginBottom: '8px', opacity: 0.5
                  }}>
                    <div style={{ fontWeight: 600 }}>{reward.rewardDescription}</div>
                    <div style={{ fontSize: '12px', color: '#9ca3af' }}>Code: {reward.rewardCode}</div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <CustomerNav />
    </div>
  );
};

export default RewardsPage;
