import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { stickerAPI, restaurantAPI } from '../services/api';
import { CustomerNav } from '../components/Navigation';
import toast from 'react-hot-toast';

const ScanPage = () => {
  const { token } = useParams();
  const navigate = useNavigate();
  const [scanning, setScanning] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [qrInfo, setQRInfo] = useState(null);
  const [scannerReady, setScannerReady] = useState(false);
  const [manualToken, setManualToken] = useState('');
  const scannerRef = useRef(null);
  const html5QrCodeRef = useRef(null);

  // If token provided in URL, process directly
  useEffect(() => {
    if (token && token !== 'demo') {
      processToken(token);
    }
  }, [token]);

  const processToken = async (qrToken) => {
    setProcessing(true);
    try {
      // First validate the QR
      const validation = await restaurantAPI.validateQR(qrToken);
      setQRInfo(validation.qr);

      // Process the scan
      const res = await stickerAPI.processScan(qrToken);
      setResult(res);

      if (res.rewardEarned) {
        toast.success('🎉 FREE reward unlocked!', { duration: 5000 });
      } else {
        toast.success(res.message);
      }
    } catch (err) {
      toast.error(err.message || 'Invalid QR code');
      setResult({ error: true, message: err.message });
    } finally {
      setProcessing(false);
    }
  };

  const startScanner = async () => {
    setScanning(true);
    setScannerReady(false);

    try {
      const { Html5Qrcode } = await import('html5-qrcode');
      html5QrCodeRef.current = new Html5Qrcode('qr-reader');

      await html5QrCodeRef.current.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        async (decodedText) => {
          // Extract token from URL or use as-is
          let extractedToken = decodedText;
          try {
            const url = new URL(decodedText);
            const pathParts = url.pathname.split('/');
            extractedToken = pathParts[pathParts.length - 1] || decodedText;
          } catch {}

          stopScanner();
          await processToken(extractedToken);
        },
        () => {}
      );
      setScannerReady(true);
    } catch (err) {
      toast.error('Camera access denied. Try manual entry.');
      setScanning(false);
    }
  };

  const stopScanner = () => {
    if (html5QrCodeRef.current) {
      html5QrCodeRef.current.stop().catch(() => {});
      html5QrCodeRef.current = null;
    }
    setScanning(false);
  };

  useEffect(() => {
    return () => stopScanner();
  }, []);

  if (processing) {
    return (
      <div className="app-container" style={{ minHeight: '100vh', background: '#1a1a2e', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', color: 'white' }}>
          <div style={{ fontSize: '64px', marginBottom: '24px', animation: 'spin 1s linear infinite' }}>⭐</div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          <h2 style={{ fontSize: '24px', fontWeight: 800 }}>Adding Sticker...</h2>
          <p style={{ opacity: 0.6 }}>Please wait</p>
        </div>
      </div>
    );
  }

  if (result) {
    return (
      <div className="app-container" style={{ minHeight: '100vh', background: result.error ? '#fef2f2' : '#faf9f7' }}>
        <div style={{ padding: '40px 24px', textAlign: 'center' }}>
          {result.error ? (
            <>
              <div style={{ fontSize: '64px', marginBottom: '16px' }}>❌</div>
              <h2 style={{ color: '#ef4444', fontWeight: 800, fontSize: '24px' }}>Scan Failed</h2>
              <p style={{ color: '#6b7280', marginBottom: '32px' }}>{result.message}</p>
            </>
          ) : result.rewardEarned ? (
            <>
              <div style={{ fontSize: '80px', marginBottom: '16px' }} className="float-animation">🎉</div>
              <h2 style={{ fontWeight: 800, fontSize: '28px', color: '#FF6B35' }}>Congratulations!</h2>
              <p style={{ color: '#6b7280', marginBottom: '20px' }}>You've earned a FREE reward!</p>
              {result.reward && (
                <div style={{
                  background: 'linear-gradient(135deg, #FFD700, #FF6B35)',
                  borderRadius: '16px', padding: '24px', marginBottom: '24px', color: 'white'
                }}>
                  <div style={{ fontSize: '13px', opacity: 0.8, marginBottom: '8px' }}>YOUR REWARD CODE</div>
                  <div style={{ fontSize: '32px', fontWeight: 800, letterSpacing: '4px' }}>{result.reward.code}</div>
                  <div style={{ fontSize: '14px', marginTop: '8px', opacity: 0.9 }}>{result.reward.description}</div>
                </div>
              )}
            </>
          ) : (
            <>
              <div style={{ fontSize: '72px', marginBottom: '16px' }}>⭐</div>
              <h2 style={{ fontWeight: 800, fontSize: '26px' }}>Sticker Added!</h2>
              {qrInfo && <p style={{ color: '#6b7280' }}>{qrInfo.restaurant?.name}</p>}
              <div style={{
                background: '#fff5f0', border: '2px solid #FF6B35', borderRadius: '16px',
                padding: '20px', margin: '20px 0'
              }}>
                <div style={{ display: 'flex', gap: '6px', justifyContent: 'center', fontSize: '24px', marginBottom: '12px' }}>
                  {Array.from({ length: result.stickersRequired || 7 }, (_, i) => (
                    <span key={i}>{i < result.stickersCollected ? '⭐' : '⬜'}</span>
                  ))}
                </div>
                <div style={{ fontWeight: 700, color: '#FF6B35' }}>
                  {result.stickersCollected} / {result.stickersRequired} stickers
                </div>
                <div style={{ fontSize: '13px', color: '#9ca3af', marginTop: '4px' }}>
                  {(result.stickersRequired || 7) - result.stickersCollected} more for FREE reward!
                </div>
              </div>
            </>
          )}

          <button className="btn-primary" onClick={() => navigate('/dashboard')}>
            Back to Dashboard
          </button>
          {!result.error && (
            <button className="btn-secondary" style={{ marginTop: '12px' }} onClick={() => setResult(null)}>
              Scan Another
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="app-container" style={{ background: '#faf9f7', paddingBottom: '100px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px', textAlign: 'center'
      }}>
        <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>📷 Scan QR Code</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', margin: '8px 0 0' }}>
          Scan the restaurant QR code to earn a sticker
        </p>
      </div>

      <div style={{ padding: '24px 20px' }}>
        {!scanning ? (
          <div>
            <div style={{
              background: 'white', borderRadius: '20px', padding: '32px',
              textAlign: 'center', marginBottom: '20px',
              boxShadow: '0 4px 24px rgba(0,0,0,0.08)'
            }}>
              <div style={{ fontSize: '80px', marginBottom: '16px' }}>📱</div>
              <h2 style={{ fontWeight: 800, marginBottom: '8px' }}>Ready to Scan</h2>
              <p style={{ color: '#9ca3af', fontSize: '14px', marginBottom: '24px' }}>
                Point your camera at the QR code at the restaurant
              </p>
              <button className="btn-primary" onClick={startScanner}>
                Open Camera 📷
              </button>
            </div>

            {/* Manual entry */}
            <div style={{ background: 'white', borderRadius: '16px', padding: '20px', boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
              <h3 style={{ fontWeight: 700, marginBottom: '12px', fontSize: '15px' }}>Or Enter Code Manually</h3>
              <input
                type="text"
                className="input-field"
                placeholder="Paste QR token here..."
                value={manualToken}
                onChange={e => setManualToken(e.target.value)}
                style={{ marginBottom: '12px' }}
              />
              <button
                className="btn-secondary"
                onClick={() => manualToken && processToken(manualToken.trim())}
                disabled={!manualToken.trim()}
              >
                Submit Token
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div style={{
              background: '#1a1a2e', borderRadius: '20px', overflow: 'hidden',
              marginBottom: '16px', minHeight: '300px', position: 'relative'
            }}>
              <div id="qr-reader" style={{ width: '100%' }} />
              {!scannerReady && (
                <div style={{
                  position: 'absolute', inset: 0, display: 'flex',
                  alignItems: 'center', justifyContent: 'center', color: 'white'
                }}>
                  <p>Starting camera...</p>
                </div>
              )}
            </div>

            <div style={{ textAlign: 'center', marginBottom: '16px', color: '#FF6B35', fontWeight: 600 }}>
              📷 Align QR code within the frame
            </div>

            <button className="btn-secondary" onClick={stopScanner}>
              Cancel Scan
            </button>
          </div>
        )}
      </div>

      <CustomerNav />
    </div>
  );
};

export default ScanPage;
