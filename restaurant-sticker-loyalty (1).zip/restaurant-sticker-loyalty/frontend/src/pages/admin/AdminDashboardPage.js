import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { adminAPI } from '../../services/api';
import { AdminNav } from '../../components/Navigation';
import toast from 'react-hot-toast';

const StatCard = ({ emoji, label, value, color = '#FF6B35' }) => (
  <div style={{
    background: 'white', borderRadius: '16px', padding: '20px',
    boxShadow: '0 2px 16px rgba(0,0,0,0.06)', textAlign: 'center'
  }}>
    <div style={{ fontSize: '28px', marginBottom: '8px' }}>{emoji}</div>
    <div style={{ fontSize: '28px', fontWeight: 800, color }}>{value}</div>
    <div style={{ fontSize: '12px', color: '#9ca3af', marginTop: '2px', fontWeight: 600 }}>{label}</div>
  </div>
);

const AdminDashboardPage = () => {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.getAnalytics()
      .then(res => setAnalytics(res.analytics))
      .catch(() => toast.error('Failed to load analytics'))
      .finally(() => setLoading(false));
  }, []);

  const formatTime = (date) => new Date(date).toLocaleTimeString('en-IN', {
    hour: '2-digit', minute: '2-digit'
  });

  const formatDate = (date) => new Date(date).toLocaleDateString('en-IN', {
    day: 'numeric', month: 'short'
  });

  return (
    <div className="app-container" style={{ background: '#f4f4f8', paddingBottom: '100px' }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px 28px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '13px', margin: '0 0 4px' }}>Admin Panel</p>
            <h1 style={{ color: 'white', fontSize: '20px', fontWeight: 800, margin: 0 }}>
              {user?.restaurantName || 'Dashboard'}
            </h1>
          </div>
          <div style={{ fontSize: '32px' }}>🎛️</div>
        </div>

        <div style={{ marginTop: '16px', display: 'flex', gap: '8px' }}>
          <div style={{
            background: 'rgba(255,107,53,0.2)', border: '1px solid rgba(255,107,53,0.4)',
            borderRadius: '20px', padding: '6px 14px', fontSize: '12px', color: '#F7C59F'
          }}>
            🕐 12:00 PM – 11:30 PM
          </div>
          <div style={{
            background: 'rgba(52,211,153,0.2)', border: '1px solid rgba(52,211,153,0.4)',
            borderRadius: '20px', padding: '6px 14px', fontSize: '12px', color: '#6ee7b7'
          }}>
            ✅ Active
          </div>
        </div>
      </div>

      <div style={{ padding: '24px 20px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#9ca3af' }}>
            <div style={{ fontSize: '40px' }}>⏳</div>
            <p>Loading analytics...</p>
          </div>
        ) : analytics ? (
          <>
            {/* Stats grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '24px' }}>
              <StatCard emoji="👥" label="Total Customers" value={analytics.totalCustomers} />
              <StatCard emoji="📷" label="Today's Scans" value={analytics.todayScans} color="#10b981" />
              <StatCard emoji="⭐" label="Stickers Issued" value={analytics.stickersIssued} color="#f59e0b" />
              <StatCard emoji="🎁" label="Rewards Redeemed" value={analytics.rewardsRedeemed} color="#8b5cf6" />
            </div>

            {/* Pending rewards alert */}
            {analytics.pendingRewards > 0 && (
              <div style={{
                background: 'linear-gradient(135deg, #FF6B35, #e55a28)',
                borderRadius: '16px', padding: '16px 20px',
                marginBottom: '20px', color: 'white',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
                <div>
                  <div style={{ fontWeight: 800 }}>🎁 {analytics.pendingRewards} Pending Rewards</div>
                  <div style={{ fontSize: '13px', opacity: 0.85 }}>Customers waiting to redeem</div>
                </div>
                <div style={{ fontSize: '24px' }}>→</div>
              </div>
            )}

            {/* Weekly chart */}
            {analytics.weeklyScans?.length > 0 && (
              <div style={{
                background: 'white', borderRadius: '16px', padding: '20px',
                marginBottom: '20px', boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
              }}>
                <h3 style={{ fontWeight: 700, marginBottom: '16px', fontSize: '15px' }}>📊 Weekly Scans</h3>
                <div style={{ display: 'flex', gap: '6px', alignItems: 'flex-end', height: '80px' }}>
                  {analytics.weeklyScans.map(day => {
                    const maxCount = Math.max(...analytics.weeklyScans.map(d => d.count));
                    const height = maxCount > 0 ? (day.count / maxCount) * 100 : 0;
                    return (
                      <div key={day._id} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                        <div style={{ fontSize: '10px', color: '#9ca3af', fontWeight: 600 }}>{day.count}</div>
                        <div style={{
                          width: '100%', height: `${height}%`, minHeight: '4px',
                          background: 'linear-gradient(to top, #FF6B35, #F7C59F)',
                          borderRadius: '4px 4px 0 0'
                        }} />
                        <div style={{ fontSize: '9px', color: '#9ca3af' }}>
                          {new Date(day._id).toLocaleDateString('en-IN', { weekday: 'short' })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Recent scans */}
            {analytics.recentScans?.length > 0 && (
              <div style={{
                background: 'white', borderRadius: '16px', padding: '20px',
                boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
              }}>
                <h3 style={{ fontWeight: 700, marginBottom: '16px', fontSize: '15px' }}>⚡ Recent Scans</h3>
                {analytics.recentScans.map((scan, i) => (
                  <div key={scan._id || i} style={{
                    display: 'flex', alignItems: 'center', gap: '12px',
                    padding: '10px 0',
                    borderBottom: i < analytics.recentScans.length - 1 ? '1px solid #f3f4f6' : 'none'
                  }}>
                    <div style={{
                      width: '36px', height: '36px', borderRadius: '50%', flexShrink: 0,
                      background: '#fff5f0', display: 'flex', alignItems: 'center',
                      justifyContent: 'center', fontSize: '16px'
                    }}>⭐</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: '14px' }}>{scan.userId?.name || 'Customer'}</div>
                      <div style={{ fontSize: '11px', color: '#9ca3af' }}>{scan.userId?.email}</div>
                    </div>
                    <div style={{ fontSize: '11px', color: '#9ca3af', textAlign: 'right' }}>
                      <div>{formatDate(scan.scanTime)}</div>
                      <div>{formatTime(scan.scanTime)}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#9ca3af' }}>
            <p>No analytics data available</p>
          </div>
        )}
      </div>

      <AdminNav />
    </div>
  );
};

export default AdminDashboardPage;
