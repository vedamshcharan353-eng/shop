import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { authAPI } from '../../services/api';
import toast from 'react-hot-toast';

const AdminLoginPage = () => {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authAPI.adminLogin(form);
      login(res.token, res.user);
      toast.success('Welcome, Admin! 🎛️');
      navigate('/admin/dashboard');
    } catch (err) {
      toast.error(err.message || 'Invalid admin credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container" style={{ minHeight: '100vh', background: '#1a1a2e' }}>
      <div style={{ padding: '60px 24px 40px', textAlign: 'center' }}>
        <div style={{ fontSize: '56px', marginBottom: '16px' }}>🎛️</div>
        <h1 style={{ color: 'white', fontSize: '26px', fontWeight: 800, margin: '0 0 8px' }}>Admin Panel</h1>
        <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '14px', margin: 0 }}>
          Restaurant owner access only
        </p>
      </div>

      <div style={{
        background: '#faf9f7', borderRadius: '32px 32px 0 0',
        padding: '32px 24px', minHeight: '60vh'
      }}>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label className="input-label">Admin Email</label>
            <input
              type="email"
              className="input-field"
              placeholder="admin@restaurant.com"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="input-label">Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="Enter admin password"
              value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })}
              required
            />
          </div>
          <button type="submit" className="btn-primary" disabled={loading} style={{ marginTop: '8px' }}>
            {loading ? 'Logging in...' : 'Admin Login 🔑'}
          </button>
        </form>

        <div style={{ marginTop: '24px', padding: '16px', background: '#f0f0f0', borderRadius: '12px' }}>
          <p style={{ margin: 0, fontSize: '12px', color: '#888', textAlign: 'center' }}>
            <strong>Default Admin:</strong> admin@restaurant.com / admin123456<br />
            POST to <code>/api/seed</code> to create this account
          </p>
        </div>

        <div style={{ textAlign: 'center', marginTop: '24px' }}>
          <Link to="/" style={{ color: '#9ca3af', fontSize: '13px' }}>← Back to home</Link>
        </div>
      </div>
    </div>
  );
};

export default AdminLoginPage;
