import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { AdminNav } from '../../components/Navigation';
import toast from 'react-hot-toast';

const AdminRewardsPage = () => {
  const [rewards, setRewards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [redeemCode, setRedeemCode] = useState('');
  const [redeeming, setRedeeming] = useState(false);
  const [redeemResult, setRedeemResult] = useState(null);

  const fetchRewards = async () => {
    try {
      const res = await adminAPI.getRewards();
      setRewards(res.rewards || []);
    } catch (err) {
      toast.error('Failed to load rewards');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchRewards(); }, []);

  const handleRedeem = async (e) => {
    e.preventDefault();
    const code = redeemCode.trim().toUpperCase();
    if (!code) return;
    setRedeeming(true);
    setRedeemResult(null);
    try {
      const res = await adminAPI.redeemReward(code);
      setRedeemResult({ success: true, ...res.reward });
      toast.success('Reward redeemed! 🎉');
      setRedeemCode('');
      fetchRewards();
    } catch (err) {
      setRedeemResult({ success: false, message: err.message });
      toast.error(err.message || 'Failed to redeem reward');
    } finally {
      setRedeeming(false);
    }
  };

  const pending = rewards.filter(r => !r.redeemed && !r.isExpired);
  const redeemed = rewards.filter(r => r.redeemed);

  return (
    <div className="app-container" style={{ background: '#f4f4f8', paddingBottom: '100px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px'
      }}>
        <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>🎁 Rewards</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', margin: '8px 0 0' }}>
          {pending.length} pending • {redeemed.length} redeemed
        </p>
      </div>

      <div style={{ padding: '24px 20px' }}>
        {/* Redeem form */}
        <div style={{
          background: 'white', borderRadius: '16px', padding: '20px',
          marginBottom: '24px', boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
        }}>
          <h3 style={{ fontWeight: 700, marginBottom: '4px', fontSize: '16px' }}>🔑 Redeem Reward</h3>
          <p style={{ color: '#9ca3af', fontSize: '13px', marginBottom: '16px', marginTop: '4px' }}>
            Enter the customer's reward code to redeem their free food
          </p>
          <form onSubmit={handleRedeem} style={{ display: 'flex', gap: '8px' }}>
            <input
              type="text"
              className="input-field"
              placeholder="Enter reward code..."
              value={redeemCode}
              onChange={e => setRedeemCode(e.target.value.toUpperCase())}
              style={{ flex: 1, textTransform: 'uppercase', letterSpacing: '2px', fontWeight: 700 }}
            />
            <button
              type="submit"
              disabled={redeeming || !redeemCode.trim()}
              style={{
                padding: '14px 20px', background: '#FF6B35', color: 'white',
                border: 'none', borderRadius: '12px', fontWeight: 700, fontFamily: 'inherit',
                cursor: 'pointer', whiteSpace: 'nowrap', fontSize: '14px'
              }}
            >
              {redeeming ? '...' : 'Redeem'}
            </button>
          </form>

          {redeemResult && (
            <div style={{
              marginTop: '16px', padding: '16px', borderRadius: '12px',
              background: redeemResult.success ? '#d1fae5' : '#fee2e2',
              border: `1px solid ${redeemResult.success ? '#a7f3d0' : '#fca5a5'}`
            }}>
              {redeemResult.success ? (
                <>
                  <div style={{ fontWeight: 700, color: '#065f46' }}>✅ Reward Redeemed!</div>
                  <div style={{ fontSize: '13px', color: '#065f46', marginTop: '4px' }}>
                    Customer: <strong>{redeemResult.customerName}</strong><br />
                    Reward: {redeemResult.description}
                  </div>
                </>
              ) : (
                <div style={{ fontWeight: 600, color: '#991b1b' }}>❌ {redeemResult.message}</div>
              )}
            </div>
          )}
        </div>

        {/* Pending rewards */}
        {pending.length > 0 && (
          <div style={{ marginBottom: '24px' }}>
            <h3 style={{ fontWeight: 700, marginBottom: '12px', fontSize: '15px', color: '#FF6B35' }}>
              ⏳ Pending Rewards
            </h3>
            {pending.map(reward => (
              <div key={reward._id} style={{
                background: 'white', borderRadius: '12px', padding: '16px',
                marginBottom: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontWeight: 700 }}>{reward.userId?.name}</div>
                    <div style={{ fontSize: '12px', color: '#9ca3af' }}>{reward.userId?.email}</div>
                    <div style={{ fontSize: '13px', color: '#6b7280', marginTop: '4px' }}>{reward.rewardDescription}</div>
                  </div>
                  <div style={{
                    background: '#fff5f0', border: '1px solid #FF6B35',
                    borderRadius: '8px', padding: '8px 12px', textAlign: 'center'
                  }}>
                    <div style={{ fontSize: '9px', color: '#9ca3af', marginBottom: '2px' }}>CODE</div>
                    <div style={{ fontWeight: 800, color: '#FF6B35', letterSpacing: '2px', fontSize: '15px' }}>
                      {reward.rewardCode}
                    </div>
                  </div>
                </div>
                <div style={{ marginTop: '12px' }}>
                  <button
                    className="btn-primary"
                    style={{ padding: '10px' }}
                    onClick={() => { setRedeemCode(reward.rewardCode); }}
                  >
                    Mark as Redeemed
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Redeemed history */}
        {redeemed.length > 0 && (
          <div>
            <h3 style={{ fontWeight: 700, marginBottom: '12px', fontSize: '15px', color: '#6b7280' }}>
              ✅ Redeemed ({redeemed.length})
            </h3>
            {redeemed.slice(0, 10).map(reward => (
              <div key={reward._id} style={{
                background: 'white', borderRadius: '12px', padding: '14px',
                marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '12px',
                opacity: 0.7, boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
              }}>
                <div style={{ fontSize: '24px' }}>✅</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>{reward.userId?.name}</div>
                  <div style={{ fontSize: '12px', color: '#9ca3af' }}>
                    {reward.rewardCode} • {new Date(reward.redeemedAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {loading && <div style={{ textAlign: 'center', padding: '40px', color: '#9ca3af' }}>⏳ Loading...</div>}
      </div>

      <AdminNav />
    </div>
  );
};

export default AdminRewardsPage;
