import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { AdminNav } from '../../components/Navigation';
import toast from 'react-hot-toast';

const AnalyticsPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [restaurant, setRestaurant] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([adminAPI.getAnalytics(), adminAPI.getRestaurant()])
      .then(([analyticsRes, restaurantRes]) => {
        setAnalytics(analyticsRes.analytics);
        setRestaurant(restaurantRes.restaurant);
      })
      .catch(() => toast.error('Failed to load analytics'))
      .finally(() => setLoading(false));
  }, []);

  const StatRow = ({ emoji, label, value, sub }) => (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '14px 0', borderBottom: '1px solid #f3f4f6'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <span style={{ fontSize: '22px' }}>{emoji}</span>
        <div>
          <div style={{ fontWeight: 600, fontSize: '14px' }}>{label}</div>
          {sub && <div style={{ fontSize: '11px', color: '#9ca3af' }}>{sub}</div>}
        </div>
      </div>
      <div style={{ fontWeight: 800, fontSize: '20px', color: '#FF6B35' }}>{value}</div>
    </div>
  );

  return (
    <div className="app-container" style={{ background: '#f4f4f8', paddingBottom: '100px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px'
      }}>
        <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>📊 Analytics</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', margin: '8px 0 0' }}>
          Business performance overview
        </p>
      </div>

      <div style={{ padding: '24px 20px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px', color: '#9ca3af' }}>⏳ Loading...</div>
        ) : analytics && (
          <>
            {/* Key metrics */}
            <div style={{
              background: 'white', borderRadius: '16px', padding: '20px',
              marginBottom: '20px', boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
            }}>
              <h3 style={{ fontWeight: 700, marginBottom: '4px', fontSize: '15px' }}>Key Metrics</h3>
              <StatRow emoji="👥" label="Total Customers" value={analytics.totalCustomers} sub="Unique loyalty members" />
              <StatRow emoji="📷" label="Total Scans" value={analytics.totalScans} sub="All time QR scans" />
              <StatRow emoji="⭐" label="Stickers Issued" value={analytics.stickersIssued} sub="Total stickers given" />
              <StatRow emoji="🎁" label="Rewards Redeemed" value={analytics.rewardsRedeemed} sub="Free food claimed" />
              <div style={{ padding: '14px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <span style={{ fontSize: '22px' }}>⏳</span>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '14px' }}>Pending Rewards</div>
                    <div style={{ fontSize: '11px', color: '#9ca3af' }}>Waiting for redemption</div>
                  </div>
                </div>
                <div style={{ fontWeight: 800, fontSize: '20px', color: '#f59e0b' }}>
                  {analytics.pendingRewards}
                </div>
              </div>
            </div>

            {/* Today */}
            <div style={{
              background: 'linear-gradient(135deg, #FF6B35, #F7C59F)',
              borderRadius: '16px', padding: '20px', marginBottom: '20px',
              display: 'flex', alignItems: 'center', gap: '16px'
            }}>
              <div style={{ fontSize: '48px' }}>🌅</div>
              <div style={{ color: 'white' }}>
                <div style={{ fontSize: '13px', opacity: 0.85 }}>Today's Scans</div>
                <div style={{ fontSize: '40px', fontWeight: 800 }}>{analytics.todayScans}</div>
              </div>
            </div>

            {/* Conversion rate */}
            {analytics.totalScans > 0 && (
              <div style={{
                background: 'white', borderRadius: '16px', padding: '20px',
                marginBottom: '20px', boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
              }}>
                <h3 style={{ fontWeight: 700, marginBottom: '16px', fontSize: '15px' }}>📈 Conversion</h3>
                <div style={{ display: 'flex', gap: '12px' }}>
                  <div style={{ flex: 1, textAlign: 'center' }}>
                    <div style={{ fontSize: '24px', fontWeight: 800, color: '#8b5cf6' }}>
                      {analytics.totalScans > 0 ? Math.round((analytics.rewardsRedeemed / analytics.totalCustomers) * 10) / 10 : 0}
                    </div>
                    <div style={{ fontSize: '12px', color: '#9ca3af' }}>Rewards/Customer</div>
                  </div>
                  <div style={{ flex: 1, textAlign: 'center' }}>
                    <div style={{ fontSize: '24px', fontWeight: 800, color: '#10b981' }}>
                      {analytics.totalCustomers > 0 ? Math.round(analytics.totalScans / analytics.totalCustomers) : 0}
                    </div>
                    <div style={{ fontSize: '12px', color: '#9ca3af' }}>Scans/Customer</div>
                  </div>
                  <div style={{ flex: 1, textAlign: 'center' }}>
                    <div style={{ fontSize: '24px', fontWeight: 800, color: '#f59e0b' }}>
                      {analytics.totalScans > 0 ? Math.round((analytics.rewardsRedeemed / analytics.totalScans) * 100 * 7) : 0}%
                    </div>
                    <div style={{ fontSize: '12px', color: '#9ca3af' }}>Completion Rate</div>
                  </div>
                </div>
              </div>
            )}

            {/* Weekly chart */}
            {analytics.weeklyScans?.length > 0 && (
              <div style={{
                background: 'white', borderRadius: '16px', padding: '20px',
                boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
              }}>
                <h3 style={{ fontWeight: 700, marginBottom: '20px', fontSize: '15px' }}>📅 Last 7 Days</h3>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-end', height: '100px' }}>
                  {(() => {
                    const last7 = [];
                    for (let i = 6; i >= 0; i--) {
                      const d = new Date();
                      d.setDate(d.getDate() - i);
                      const key = d.toISOString().split('T')[0];
                      const found = analytics.weeklyScans.find(s => s._id === key);
                      last7.push({ date: key, count: found?.count || 0, label: d.toLocaleDateString('en-IN', { weekday: 'short' }) });
                    }
                    const max = Math.max(...last7.map(d => d.count), 1);
                    return last7.map(day => (
                      <div key={day.date} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                        <div style={{ fontSize: '11px', color: '#9ca3af', fontWeight: 600 }}>{day.count}</div>
                        <div style={{
                          width: '100%', height: `${(day.count / max) * 80 + 4}px`,
                          background: day.count > 0 ? 'linear-gradient(to top, #FF6B35, #F7C59F)' : '#f3f4f6',
                          borderRadius: '4px 4px 0 0', minHeight: '4px',
                          transition: 'height 0.3s'
                        }} />
                        <div style={{ fontSize: '9px', color: '#9ca3af' }}>{day.label}</div>
                      </div>
                    ));
                  })()}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <AdminNav />
    </div>
  );
};

export default AnalyticsPage;
