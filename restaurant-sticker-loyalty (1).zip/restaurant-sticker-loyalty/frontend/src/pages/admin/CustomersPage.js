import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { AdminNav } from '../../components/Navigation';
import toast from 'react-hot-toast';

const CustomersPage = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    adminAPI.getCustomers()
      .then(res => setCustomers(res.customers || []))
      .catch(() => toast.error('Failed to load customers'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = customers.filter(c =>
    c.user?.name?.toLowerCase().includes(search.toLowerCase()) ||
    c.user?.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="app-container" style={{ background: '#f4f4f8', paddingBottom: '100px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px'
      }}>
        <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>👥 Customers</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', margin: '8px 0 0' }}>
          {customers.length} total customers
        </p>
      </div>

      <div style={{ padding: '16px 20px 0' }}>
        <input
          type="text"
          className="input-field"
          placeholder="🔍 Search customers..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div style={{ padding: '16px 20px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>⏳ Loading...</div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '48px', background: 'white', borderRadius: '16px', color: '#9ca3af' }}>
            <div style={{ fontSize: '48px', marginBottom: '8px' }}>👥</div>
            {search ? 'No customers found' : 'No customers yet'}
          </div>
        ) : (
          filtered.map((customer, i) => {
            const stickers = customer.activeCard?.stickersCollected || 0;
            const required = 7;
            const daysLeft = customer.activeCard?.expiryDate
              ? Math.max(0, Math.ceil((new Date(customer.activeCard.expiryDate) - new Date()) / 86400000))
              : null;

            return (
              <div key={customer.user?._id || i} style={{
                background: 'white', borderRadius: '16px', padding: '16px',
                marginBottom: '12px', boxShadow: '0 2px 12px rgba(0,0,0,0.06)'
              }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                  <div style={{
                    width: '44px', height: '44px', borderRadius: '50%', flexShrink: 0,
                    background: 'linear-gradient(135deg, #FF6B35, #F7C59F)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: 'white', fontWeight: 800, fontSize: '18px'
                  }}>
                    {customer.user?.name?.charAt(0).toUpperCase() || '?'}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: '15px' }}>{customer.user?.name}</div>
                    <div style={{ fontSize: '12px', color: '#9ca3af' }}>{customer.user?.email}</div>
                    {customer.user?.phone && <div style={{ fontSize: '12px', color: '#9ca3af' }}>{customer.user.phone}</div>}
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '11px', color: '#9ca3af', marginBottom: '2px' }}>Cards</div>
                    <div style={{ fontWeight: 800, color: '#FF6B35' }}>{customer.totalCards}</div>
                  </div>
                </div>

                {customer.activeCard && (
                  <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid #f3f4f6' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: '#6b7280' }}>Active Card Progress</div>
                      {daysLeft !== null && (
                        <div style={{
                          fontSize: '11px',
                          color: daysLeft <= 3 ? '#ef4444' : daysLeft <= 7 ? '#f59e0b' : '#10b981',
                          fontWeight: 600
                        }}>
                          {daysLeft}d left
                        </div>
                      )}
                    </div>
                    <div style={{ display: 'flex', gap: '4px', marginBottom: '8px' }}>
                      {Array.from({ length: required }, (_, i) => (
                        <div key={i} style={{
                          flex: 1, height: '6px', borderRadius: '3px',
                          background: i < stickers ? '#FF6B35' : '#e5e7eb',
                          transition: 'background 0.2s'
                        }} />
                      ))}
                    </div>
                    <div style={{ fontSize: '11px', color: '#9ca3af' }}>
                      {stickers}/{required} stickers
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      <AdminNav />
    </div>
  );
};

export default CustomersPage;
