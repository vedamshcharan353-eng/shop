import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import { AdminNav } from '../../components/Navigation';
import toast from 'react-hot-toast';

const QRGeneratorPage = () => {
  const [qrCodes, setQRCodes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [form, setForm] = useState({ label: '', tableNumber: '' });
  const [selectedQR, setSelectedQR] = useState(null);

  const fetchQRCodes = async () => {
    try {
      const res = await adminAPI.getQRCodes();
      setQRCodes(res.qrCodes || []);
    } catch (err) {
      toast.error('Failed to load QR codes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchQRCodes(); }, []);

  const handleGenerate = async (e) => {
    e.preventDefault();
    setGenerating(true);
    try {
      const res = await adminAPI.generateQR(form);
      toast.success('QR code generated! ✅');
      setForm({ label: '', tableNumber: '' });
      setSelectedQR(res.qr);
      fetchQRCodes();
    } catch (err) {
      toast.error(err.message || 'Failed to generate QR');
    } finally {
      setGenerating(false);
    }
  };

  const handleToggle = async (id) => {
    try {
      const res = await adminAPI.toggleQR(id);
      toast.success(res.message);
      fetchQRCodes();
    } catch (err) {
      toast.error('Failed to update QR');
    }
  };

  const downloadQR = (qr) => {
    if (!qr.qrImageUrl) return;
    const link = document.createElement('a');
    link.href = qr.qrImageUrl;
    link.download = `qr-${qr.label || qr.token}.png`;
    link.click();
    toast.success('QR downloaded!');
  };

  return (
    <div className="app-container" style={{ background: '#f4f4f8', paddingBottom: '100px' }}>
      <div style={{
        background: 'linear-gradient(135deg, #1a1a2e, #0f3460)',
        padding: '24px 20px'
      }}>
        <h1 style={{ color: 'white', fontSize: '22px', fontWeight: 800, margin: 0 }}>📱 QR Codes</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '14px', margin: '8px 0 0' }}>
          Generate and manage QR codes
        </p>
      </div>

      <div style={{ padding: '24px 20px' }}>
        {/* Generate form */}
        <div style={{
          background: 'white', borderRadius: '16px', padding: '20px',
          marginBottom: '24px', boxShadow: '0 2px 16px rgba(0,0,0,0.06)'
        }}>
          <h3 style={{ fontWeight: 700, marginBottom: '16px', fontSize: '15px' }}>Generate New QR Code</h3>
          <form onSubmit={handleGenerate} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div>
              <label className="input-label">Label</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g., Table 1, Bill Counter"
                value={form.label}
                onChange={e => setForm({ ...form, label: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="input-label">Table Number (optional)</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g., T1, T2"
                value={form.tableNumber}
                onChange={e => setForm({ ...form, tableNumber: e.target.value })}
              />
            </div>
            <button type="submit" className="btn-primary" disabled={generating}>
              {generating ? 'Generating...' : '➕ Generate QR Code'}
            </button>
          </form>
        </div>

        {/* Selected QR preview */}
        {selectedQR && (
          <div style={{
            background: 'white', borderRadius: '16px', padding: '24px',
            marginBottom: '24px', boxShadow: '0 4px 24px rgba(0,0,0,0.1)',
            textAlign: 'center'
          }}>
            <div style={{ fontWeight: 800, fontSize: '18px', marginBottom: '4px' }}>✅ QR Generated!</div>
            <div style={{ color: '#9ca3af', fontSize: '13px', marginBottom: '16px' }}>{selectedQR.label}</div>
            {selectedQR.qrImageDataUrl && (
              <img
                src={selectedQR.qrImageDataUrl}
                alt="QR Code"
                style={{ width: '200px', height: '200px', borderRadius: '12px', marginBottom: '16px' }}
              />
            )}
            <div style={{ fontSize: '11px', color: '#9ca3af', marginBottom: '16px', wordBreak: 'break-all' }}>
              {selectedQR.scanUrl}
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                className="btn-primary"
                onClick={() => downloadQR({ qrImageUrl: selectedQR.qrImageDataUrl, label: selectedQR.label, token: selectedQR.token })}
              >
                ⬇️ Download QR
              </button>
              <button className="btn-secondary" onClick={() => setSelectedQR(null)}>
                Close
              </button>
            </div>
          </div>
        )}

        {/* QR codes list */}
        <h3 style={{ fontWeight: 700, marginBottom: '16px', fontSize: '16px' }}>
          All QR Codes ({qrCodes.length})
        </h3>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#9ca3af' }}>⏳ Loading...</div>
        ) : qrCodes.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px', background: 'white', borderRadius: '16px', color: '#9ca3af' }}>
            No QR codes yet. Generate your first one!
          </div>
        ) : (
          qrCodes.map(qr => (
            <div key={qr._id} style={{
              background: 'white', borderRadius: '12px', padding: '16px',
              marginBottom: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                {qr.qrImageUrl ? (
                  <img src={qr.qrImageUrl} alt="" style={{ width: '60px', height: '60px', borderRadius: '8px' }} />
                ) : (
                  <div style={{ width: '60px', height: '60px', background: '#f3f4f6', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px' }}>📱</div>
                )}
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700 }}>{qr.label}</div>
                  {qr.tableNumber && <div style={{ fontSize: '12px', color: '#9ca3af' }}>Table: {qr.tableNumber}</div>}
                  <div style={{ fontSize: '11px', color: '#9ca3af' }}>Scanned {qr.scanCount} times</div>
                </div>
                <span className={`badge ${qr.isActive ? 'badge-success' : 'badge-danger'}`}>
                  {qr.isActive ? 'Active' : 'Off'}
                </span>
              </div>

              <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
                <button
                  onClick={() => downloadQR(qr)}
                  style={{
                    flex: 1, padding: '8px', background: '#f3f4f6', border: 'none',
                    borderRadius: '8px', fontSize: '13px', fontWeight: 600,
                    cursor: 'pointer', fontFamily: 'inherit'
                  }}
                  disabled={!qr.qrImageUrl}
                >
                  ⬇️ Download
                </button>
                <button
                  onClick={() => handleToggle(qr._id)}
                  style={{
                    flex: 1, padding: '8px', border: 'none', borderRadius: '8px',
                    fontSize: '13px', fontWeight: 600, cursor: 'pointer',
                    fontFamily: 'inherit',
                    background: qr.isActive ? '#fee2e2' : '#d1fae5',
                    color: qr.isActive ? '#991b1b' : '#065f46'
                  }}
                >
                  {qr.isActive ? '🚫 Disable' : '✅ Enable'}
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <AdminNav />
    </div>
  );
};

export default QRGeneratorPage;
