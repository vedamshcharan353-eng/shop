import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' }
});

// Request interceptor: add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor: handle auth errors
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error.response?.data || error);
  }
);

// Auth
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  adminLogin: (data) => api.post('/auth/admin/login', data),
  getMe: () => api.get('/auth/me'),
  updatePushSubscription: (subscription) => api.post('/auth/push-subscription', { subscription })
};

// Stickers
export const stickerAPI = {
  getStickerCard: (restaurantId) => api.get(`/stickers/${restaurantId}`),
  processScan: (qrToken) => api.post('/stickers/scan', { qrToken }),
  getScanHistory: (page = 1) => api.get(`/stickers/history?page=${page}`),
  getUserRewards: () => api.get('/stickers/rewards'),
  getUserCards: () => api.get('/stickers/cards')
};

// Admin
export const adminAPI = {
  getAnalytics: () => api.get('/admin/analytics'),
  generateQR: (data) => api.post('/admin/qr/generate', data),
  getQRCodes: () => api.get('/admin/qr'),
  toggleQR: (id) => api.put(`/admin/qr/${id}/toggle`),
  getCustomers: () => api.get('/admin/customers'),
  getRewards: () => api.get('/admin/rewards'),
  redeemReward: (code) => api.put(`/admin/rewards/${code}/redeem`),
  getRestaurant: () => api.get('/admin/restaurant'),
  updateRestaurant: (data) => api.put('/admin/restaurant', data)
};

// Restaurants (public)
export const restaurantAPI = {
  getRestaurant: (id) => api.get(`/restaurants/${id}`),
  validateQR: (token) => api.get(`/restaurants/qr/${token}`)
};

export default api;
